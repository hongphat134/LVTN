<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BangCap extends Model
{
    //
    protected $table = 'bangcap';
}
