<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CapBac extends Model
{
    //
    protected $table = 'capbac';
}
