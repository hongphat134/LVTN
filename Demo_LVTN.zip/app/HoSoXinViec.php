<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HoSoXinViec extends Model
{
    //
    protected $table = 'hosoxinviec';

	public $timestamps = false;
}
