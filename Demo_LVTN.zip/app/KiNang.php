<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KiNang extends Model
{
    //
    protected $table = 'kinang';
}
