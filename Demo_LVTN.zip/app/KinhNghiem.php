<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KinhNghiem extends Model
{
    //
    protected $table = 'kinhnghiem';
}
