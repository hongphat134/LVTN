<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NganhNghe extends Model
{
    //
    protected $table = 'nganhnghe';
}
