<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NhaTuyenDung extends Model
{
    //
    protected $table = 'nhatuyendung';

    protected $primaryKey = 'idUser';

	public $timestamps = true;

}
