<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TinTuyenDung extends Model
{
    //
    protected $table = 'tintuyendung';

	public $timestamps = true;
}
