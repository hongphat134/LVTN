<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ykien extends Model
{
    //
    protected $table = 'other';

	public $timestamps = true;
}
