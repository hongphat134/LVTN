<!-- ========== Left Sidebar Start ========== -->

            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">                    
                    <!--- Divider -->


                    <div id="sidebar-menu">
                        <ul>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-newspaper"></i> <span> Tin tuyển dụng </span> <span class="float-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="{{url('/administrators/tin-tuyen-dung/danh-sach')}}">Danh sách</a></li>
                                    <li><a href="{{url('/administrators/tin-tuyen-dung/phe-duyet')}}">Phê duyệt</a></li>                                    
                                </ul>
                            </li>

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-file-account"></i> <span> Hồ sơ </span> <span class="float-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="{{url('/administrators/ho-so/danh-sach')}}">Danh sách</a></li>
                                    <li><a href="{{url('/administrators/ho-so/phe-duyet')}}">Phê duyệt</a></li>                                    
                                </ul>
                            </li>
                            
                            <li>
                                <a href="{{url('/administrators/lien-he')}}" class="waves-effect"><i class="mdi mdi-contact-mail"></i><span> Liên hệ <span class="badge badge-pill badge-primary float-right">1</span></span></a>
                            </li>

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-account"></i> <span> Người dùng </span> <span class="float-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="{{url('/administrators/nguoi-dung/nguoi-tim-viec')}}">Người tìm việc</a></li>
                                    <li><a href="{{url('/administrators/nguoi-dung/nha-tuyen-dung')}}">Nhà tuyển dụng</a></li>                                    
                                </ul>
                            </li>

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-account-group"></i> <span> Quản trị viên </span> <span class="float-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="{{url('/administrators/quan-tri-vien/danh-sach')}}">Danh sách</a></li>                                    
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="clearfix"></div>
                </div> <!-- end sidebarinner -->
            </div>
            <!-- Left Sidebar End -->