Chào bạn, {{$user->ho.' '.$user->ten}}!</br>
Chúng tôi đã nhận được ý kiến từ bạn!</br>

Tiêu đề: {{$user->tieude}} </br>
Lời nhắn: {{$user->noidung}} </br>
<hr>

Chúng tôi xin giải đáp vấn đề này là:
{{$repond}}
<hr>

Cảm ơn bạn đã quan tâm và sử dụng dịch vụ của chúng tôi!