@include('layouts.header')

@include('layouts.menu')

@yield('content')

@include('layouts.footer')