<!-- INFO -->
<table>
	<thead>
	<tr>
		<td>{{$test}}</td>
		<td>Tiêu đề hồ sơ</td>
		<td>Trình độ + Kinh Nghiệm</td>
		<td>Mức lương mong muốn???</td>
		<td>Tỉnh/thành phố</td>
		<td>Cập nhật</td>
	</tr>
	</thead>

	<tbody>
	<tr>
		<td>
			<!-- Tên ngành nghề --></br>
			<!-- Họ tên -->
		</td>
		<td>
			<!-- Trình độ -->/br>
			<!-- Kinh Nghiệm -->
		</td>
		<td>
			<!-- Mức lương mong muốn? này chưa rõ -->
		</td>
		<td>
			<!-- Tỉnh thành phố -->
		</td>
		<td>
			<!-- Ngày cập nhật -->
		</td>
	</tr>
	</tbody>
</table>