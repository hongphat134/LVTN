@include('layouts.header')

@include('ntd_layouts.menu')
  
@yield('content')

@include('layouts.footer')