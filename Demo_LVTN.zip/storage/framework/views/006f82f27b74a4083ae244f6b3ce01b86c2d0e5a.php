<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold"><?php echo e($news->nganh); ?></h1>
            <div class="custom-breadcrumbs">
              <a href="#">Home</a> <span class="mx-2 slash">/</span>
              <a href="#">Job</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong><?php echo e($news->nganh); ?></strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <section class="site-section">
      <div class="container">
        <div class="row align-items-center mb-5">
          <div class="col-lg-8 mb-4 mb-lg-0">
            <div class="d-flex align-items-center">
              <div class="border p-2 d-inline-block mr-3 rounded">
                <!-- <img src="images/job_logo_5.jpg" alt="Image"> -->
                <img src="<?php echo e(asset('logo/'.$news->hinh)); ?>" alt="Image">
              </div>
              <div>
                <h2><?php echo e($news->nganh); ?></h2>
                <div>
                  <span class="ml-0 mr-2 mb-2"><span class="icon-briefcase mr-2"></span><?php echo e($news->ten); ?></span>
                  <span class="m-2"><span class="icon-clock-o mr-2"></span><span class="text-primary"><?php echo e($news->trangthailv); ?></span></span></br>
                  <?php $__currentLoopData = json_decode($news->tinhthanhpho); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="ml-0 mr-2 mb-2"><span class="icon-room mr-2"></span><?php echo e($city); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
                  <hr class="hr-text" data-content="Yêu cầu kĩ năng">
                  <div class="keywords">
                  <?php $__currentLoopData = $news->kinang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <button class="btn btn-outline-info btn-sm"><?php echo e($skill->ten); ?></button>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
                  </div>   
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="row">
              <div class="col-6 follow">
              <?php if(Auth::check()): ?> 
                <?php if(!empty(Auth::user()->theodoi)): ?>
                  <?php if(in_array($news->id,json_decode(Auth::user()->theodoi))): ?>
                  <a href="javascript:void(0)" id="<?php echo e($news->id); ?>" class="btn btn-block btn-dark btn-md">
                  <span class="icon-heart mr-2 text-danger"></span>
                  Đang theo dõi
                  </a>   
                  <?php else: ?>             
                  <a href="javascript:void(0)" id="<?php echo e($news->id); ?>" class="btn btn-block btn-light btn-md follow-news">
                  <span class="icon-heart-o mr-2 text-danger"></span>
                  Theo dõi tin tuyển dụng
                  </a>  
                  <?php endif; ?>                          
                <?php else: ?>
                <a href="javascript:void(0)" id="<?php echo e($news->id); ?>" class="btn btn-block btn-light btn-md follow-news">
                  <span class="icon-heart-o mr-2 text-danger"></span>
                  Theo dõi tin tuyển dụng
                </a>
                <?php endif; ?>
              <?php endif; ?>
              </div>
              <div class="col-6">
                <?php if(empty($hoso)): ?>
               <!--  <a href="" class="btn btn-block btn-primary btn-md">Ứng tuyển</a>       -->          
                <a href="<?php echo e(url('/nguoitimviec/choose-apply',$news->id)); ?>" class="btn btn-block btn-primary btn-md">Ứng tuyển</a> 
                <?php else: ?>                
                <a href="javascript:void(0)" class="btn btn-block btn-danger btn-md">Đã nộp đơn vào </br>
                  <?php echo e(date("d-m-Y", strtotime($hoso->created_at))); ?>

                </a>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-8">
            <div class="mb-5">
              <figure class="mb-5"><img src="<?php echo e(url('images/job_single_img_1.jpg')); ?>" alt="Image" class="img-fluid rounded"></figure>
              <h3 class="h5 d-flex align-items-center mb-4 text-primary"><span class="icon-align-left mr-3"></span>Mô tả công việc</h3>
               <ul class="list-unstyled m-0 p-0">
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span><?php echo $news->motacv; ?></span></li>
              </ul>              
            </div>
            <div class="mb-5">
              <h3 class="h5 d-flex align-items-center mb-4 text-primary"><span class="icon-rocket mr-3"></span>Responsibilities</h3>
              <ul class="list-unstyled m-0 p-0">
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Necessitatibus quibusdam facilis</span></li>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Velit unde aliquam et voluptas reiciendis n Velit unde aliquam et voluptas reiciendis non sapiente labore</span></li>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Commodi quae ipsum quas est itaque</span></li>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Lorem ipsum dolor sit amet, consectetur adipisicing elit</span></li>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Deleniti asperiores blanditiis nihil quia officiis dolor</span></li>
              </ul>
            </div>

            <div class="mb-5">
              <h3 class="h5 d-flex align-items-center mb-4 text-primary"><span class="icon-book mr-3"></span>Education + Experience</h3>
              <ul class="list-unstyled m-0 p-0">
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Necessitatibus quibusdam facilis</span></li>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Velit unde aliquam et voluptas reiciendis non sapiente labore</span></li>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Commodi quae ipsum quas est itaque</span></li>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Lorem ipsum dolor sit amet, consectetur adipisicing elit</span></li>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Deleniti asperiores blanditiis nihil quia officiis dolor</span></li>
              </ul>
            </div>

            <div class="mb-5">
              <h3 class="h5 d-flex align-items-center mb-4 text-primary"><span class="icon-turned_in mr-3"></span>Những quyền lợi khác</h3>
              <ul class="list-unstyled m-0 p-0">
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span><?php echo e($news->quyenloi); ?></span></li>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Velit unde aliquam et voluptas reiciendis non sapiente labore</span></li>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Commodi quae ipsum quas est itaque</span></li>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Lorem ipsum dolor sit amet, consectetur adipisicing elit</span></li>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span>Deleniti asperiores blanditiis nihil quia officiis dolor</span></li>
              </ul>
            </div>

            <div class="row mb-5">
              <?php if(Auth::check()): ?>
                <?php if(!empty(Auth::user()->theodoi)): ?>
                  <?php if(in_array($news->id,json_decode(Auth::user()->theodoi))): ?>
                  <div class="col-6 follow">                
                    <a href="javascript:void(0)" id="<?php echo e($news->id); ?>" class="btn btn-block btn-dark btn-md"><span class="icon-heart mr-2 text-danger"></span>Đang theo dõi</a>
                  </div>   
                  <?php else: ?>
                  <div class="col-6 follow">                
                    <a href="javascript:void(0)" id="<?php echo e($news->id); ?>" class="btn btn-block btn-light btn-md follow-news"><span class="icon-heart-o mr-2 text-danger"></span>Theo dõi tin tuyển dụng</a>                
                  </div>             
                  <?php endif; ?>
                <?php else: ?>
                <div class="col-6 follow">                
                  <a href="javascript:void(0)" id="<?php echo e($news->id); ?>" class="btn btn-block btn-light btn-md follow-news"><span class="icon-heart-o mr-2 text-danger"></span>Theo dõi tin tuyển dụng</a>                
                </div>
                <?php endif; ?>
              <?php endif; ?>
              <div class="col-6">
                <?php if(empty($hoso)): ?>
                <a href="<?php echo e(route('apply',$news->id)); ?>" class="btn btn-block btn-primary btn-md">Ứng tuyển</a>
                <?php else: ?>
                <a href="javascript:void(0)" class="btn btn-block btn-danger btn-md">Đã nộp đơn vào <?php echo e(date('d-m-Y',strtotime($hoso->created_at))); ?></a>
                <?php endif; ?>
              </div>
            </div>

          </div>
          <div class="col-lg-4">
            <div class="bg-light p-3 border rounded mb-4">
             
              <h3 class="text-primary  mt-3 h5 pl-3 mb-3 ">Tổng quan</h3>
              <ul class="list-unstyled pl-3 mb-0">
                <li class="mb-2"><strong class="text-black">Ngày đăng:</strong> <?php echo e(date("d-m-Y", strtotime($news->created_at))); ?></li>
                <li class="mb-2"><strong class="text-black">Số lượng:</strong> <?php echo e($news->soluong); ?></li>
                <li class="mb-2"><strong class="text-black">Yêu cầu trình độ:</strong> <?php echo e($news->bangcap); ?></li>
                <li class="mb-2"><strong class="text-black">Yêu cầu kĩ năng:</strong> 
                
                <?php $__currentLoopData = $news->kinang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge badge-info"><?php echo e($skill->ten); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </li>
                <li class="mb-2"><strong class="text-black">Trạng thái làm việc:</strong> <?php echo e($news->trangthailv); ?></li>
                <li class="mb-2"><strong class="text-black">Kinh nghiệm:</strong> <?php echo e($news->kinhnghiem); ?></li>
                <li class="mb-2"><strong class="text-black">Khu vực làm việc:</strong> 
                  <?php $__currentLoopData = json_decode($news->tinhthanhpho); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="badge badge-dark"><?php echo e($tp); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
                <li class="mb-2"><strong class="text-black">Mức lương:</strong> <?php echo $news->mucluong; ?></li>
                <li class="mb-2"><strong class="text-black">Giới tính:</strong> <?php echo e($news->gioitinh); ?></li>
                <li class="mb-2"><strong class="text-black">Hạn tuyển dụng: </strong><span class="text-danger"><?php echo e(date("d-m-Y", strtotime($news->hantuyendung))); ?></span></li>
              </ul>
            </div>

            <div class="bg-light p-3 border rounded">
              <h3 class="text-primary  mt-3 h5 pl-3 mb-3 ">Share</h3>
              <div class="px-3">
                <a href="#" class="pt-3 pb-3 pr-3 pl-0"><span class="icon-facebook"></span></a>
                <a href="#" class="pt-3 pb-3 pr-3 pl-0"><span class="icon-twitter"></span></a>
                <a href="#" class="pt-3 pb-3 pr-3 pl-0"><span class="icon-linkedin"></span></a>
                <a href="#" class="pt-3 pb-3 pr-3 pl-0"><span class="icon-pinterest"></span></a>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>

    <section class="site-section" id="next">
      <div class="container">
        <div class="row mb-5 justify-content-center">
          <div class="col-md-7 text-center">
            <h2 class="section-title mb-2"><?php echo e($related_jobs->count()); ?> Related Jobs</h2>
          </div>
        </div>
        
        <ul class="job-listings mb-5">
          <?php $__currentLoopData = $related_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="job-listing d-block d-sm-flex pb-3 pb-sm-0 align-items-center">
            <a href="<?php echo e(route('news',$job->id)); ?>"></a>
            <div class="job-listing-logo">
              <img src="<?php echo e(url('logo/'.$job->hinh)); ?>" alt="Free Website Template by Free-Template.co" class="img-fluid">
            </div>

            <div class="job-listing-about d-sm-flex custom-width w-100 justify-content-between mx-4">
              <div class="job-listing-position custom-width w-50 mb-3 mb-sm-0">
                <h2><?php echo e($job->nganh); ?></h2>
                <strong><?php echo e($job->ten); ?></strong>
                <div class="keywords">
                  <?php $__currentLoopData = $job->kinang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <button class="btn btn-outline-info skill"><?php echo e($skill->ten); ?></button>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                </div>      
              </div>
              <div class="job-listing-location mb-3 mb-sm-0 custom-width w-25">  
                <?php $__currentLoopData = json_decode($job->tinhthanhpho); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="icon-room"></span><?php echo e($city); ?></br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="job-listing-meta">
                <?php if($job->trangthailv == 'Part Time'): ?>
                <span class="badge badge-danger"><?php echo e($job->trangthailv); ?></span>
                <?php else: ?>
                <span class="badge badge-success"><?php echo e($job->trangthailv); ?></span>
                <?php endif; ?>
              </div>
            </div>            
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
        </ul>

        <!-- <div class="row pagination-wrap">
          <div class="col-md-6 text-center text-md-left mb-4 mb-md-0">
            <span>Showing 1-7 Of 22,392 Jobs</span>
          </div>          
        </div> -->

      </div>
    </section>
    

    <section class="bg-light pt-5 testimony-full">
        
        <div class="owl-carousel single-carousel">

        
          <div class="container">
            <div class="row">
              <div class="col-lg-6 align-self-center text-center text-lg-left">
                <blockquote>
                  <p>&ldquo;Soluta quasi cum delectus eum facilis recusandae nesciunt molestias accusantium libero dolores repellat id in dolorem laborum ad modi qui at quas dolorum voluptatem voluptatum repudiandae.&rdquo;</p>
                  <p><cite> &mdash; Corey Woods, @Dribbble</cite></p>
                </blockquote>
              </div>
              <div class="col-lg-6 align-self-end text-center text-lg-right">
                <img src="<?php echo e(url('images/person_transparent_2.png')); ?>" alt="Image" class="img-fluid mb-0">
              </div>
            </div>
          </div>

          <div class="container">
            <div class="row">
              <div class="col-lg-6 align-self-center text-center text-lg-left">
                <blockquote>
                  <p>&ldquo;Soluta quasi cum delectus eum facilis recusandae nesciunt molestias accusantium libero dolores repellat id in dolorem laborum ad modi qui at quas dolorum voluptatem voluptatum repudiandae.&rdquo;</p>
                  <p><cite> &mdash; Chris Peters, @Google</cite></p>
                </blockquote>
              </div>
              <div class="col-lg-6 align-self-end text-center text-lg-right">
                <img src="<?php echo e(url('images/person_transparent.png')); ?>" alt="Image" class="img-fluid mb-0">
              </div>
            </div>
          </div>

      </div>

    </section>

    <section class="pt-5 bg-image overlay-primary fixed overlay" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)">
      <div class="container">
        <div class="row">
          <div class="col-md-6 align-self-center text-center text-md-left mb-5 mb-md-0">
            <h2 class="text-white">Get The Mobile Apps</h2>
            <p class="mb-5 lead text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit tempora adipisci impedit.</p>
            <p class="mb-0">
              <a href="#" class="btn btn-dark btn-md px-4 border-width-2"><span class="icon-apple mr-3"></span>App Store</a>
              <a href="#" class="btn btn-dark btn-md px-4 border-width-2"><span class="icon-android mr-3"></span>Play Store</a>
            </p>
          </div>
          <div class="col-md-6 ml-auto align-self-end">
            <img src="<?php echo e(url('images/apps.png')); ?>" alt="Image" class="img-fluid">
          </div>
        </div>
      </div>
    </section>

    <!-- Ajax -->
    <script src="<?php echo e(url('ajax/save-job.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>