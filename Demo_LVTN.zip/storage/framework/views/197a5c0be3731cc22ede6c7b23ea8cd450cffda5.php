<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Mẫu hồ sơ</h1>
            <div class="custom-breadcrumbs">
              <a href="#">Home</a> <span class="mx-2 slash">/</span>
              <a href="#">Job</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Mẫu hồ sơ</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    
    <section class="site-section">
      <div class="container">

        <div class="row align-items-center mb-5">
          <div class="col-lg-8 mb-4 mb-lg-0">
            <div class="d-flex align-items-center">
              <div>
                <h2>Mẫu hồ sơ</h2>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="row">
              <div class="col-6">
                <a href="#" class="btn btn-block btn-light btn-md"><span class="icon-open_in_new mr-2"></span>Preview</a>
              </div>
              <div class="col-6">
                <a href="#" class="btn btn-block btn-primary btn-md"
                    onclick="event.preventDefault();
                           document.getElementById('profile').submit();">
                Save Job
              </a>
              </div>
            </div>
          </div>
        </div>
        <div class="row mb-5">
          <div class="col-lg-12">
            <form id="profile" action="<?php echo e(url('/nguoitimviec/profile')); ?>" class="p-4 p-md-5 border rounded" method="post" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <h3 class="text-black mb-5 border-bottom pb-2">Thông tin hồ sơ</h3>
              
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="alert alert-danger alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
               <?php echo e($error); ?>

              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php if(session('success')): ?>
              <div class="alert alert-success alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <?php echo e(session('success')); ?>

              </div>
              <?php endif; ?>
              
              <div class="form-group">
                <label for="company-website-tw d-block">Upload ảnh đại diện</label> <br>
                <label class="btn btn-primary btn-md btn-file">
                  Browse File<input type="file" name="hinhthe" hidden>
                </label>
              </div>

              <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" class="form-control" id="email" placeholder="Nhập Email...." value="<?php echo e(!empty($hoso)?$hoso->emaillienhe:''); ?>" required>
              </div>

              <div class="form-group">
                <label for="job-title">Ngành nghề</label>
                <!-- <input type="text" name="job" class="form-control" id="job-title" placeholder="Product Designer"> -->
                <select class="selectpicker border rounded" name="title" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn ngành nghề" required>                
                      <?php $__currentLoopData = $ds_job; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(!empty($hoso)): ?>
                      <option <?php echo e(strcasecmp($hoso->nganh,$job->ten) == 0?'selected':''); ?>><?php echo e($job->ten); ?></option>
                      <?php else: ?>
                      <option><?php echo e($job->ten); ?></option>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="form-group">
                <label for="job-region">Kĩ năng cá nhân</label>
                <select class="selectpicker border rounded" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" name="skill[]" title="Chọn kĩ năng..." multiple data-max-options="5">
                      <?php $__currentLoopData = $skill_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($skill->id); ?>"
                        <?php if(!empty($hoso)): ?>
              <?php echo e(in_array($skill->id,json_decode($hoso->kinang))?'selected':''); ?>

                        <?php endif; ?>>
                        <?php echo e($skill->ten); ?>

                      </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
              </div>

              <div class="form-group">
                <label for="job-region">Số năm kinh nghiệm</label>
                <select class="selectpicker border rounded" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" name="exp" title="Chọn kinh nghiệm...">
                      <?php $__currentLoopData = $exp_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option
                        <?php if(!empty($hoso)): ?>
                          <?php echo e($hoso->kinhnghiem == $exp->ten ? 'selected':''); ?>

                        <?php endif; ?>
                      >
                        <?php echo e($exp->ten); ?>

                      </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
              </div>
              
              <div class="form-group">
                <label for="job-title">Bằng cấp cao nhất</label>
                <select class="selectpicker border rounded" name="degree" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn bằng cấp" required>                
                      <?php $__currentLoopData = $ds_bc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(!empty($hoso)): ?>
                      <option <?php echo e(strcasecmp($hoso->bangcap,$bc->ten) == 0?'selected':''); ?>><?php echo e($bc->ten); ?></option>
                      <?php else: ?>
                      <option><?php echo e($bc->ten); ?></option>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="form-group">
                <label for="job-title">Cấp bậc cao nhất</label>
                <select class="selectpicker border rounded" name="rank" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn cấp bậc" required>                
                      <?php $__currentLoopData = $ds_cb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                      <?php if(!empty($hoso)): ?>
                      <option <?php echo e(strcasecmp($hoso->capbac,$cb->ten) == 0?'selected':''); ?>><?php echo e($cb->ten); ?></option>
                      <?php else: ?>
                      <option><?php echo e($cb->ten); ?></option>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="form-group">
                <label for="job-title">Tình trạng hôn nhân</label>
                <select class="selectpicker border rounded" name="marital_stt" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true">    
                      <?php if(!empty($hoso)): ?>
                        <?php if($hoso->honnhan == 'Đã kết hôn'): ?>
                        <option>Độc thân</option>
                        <option selected>Đã kết hôn</option>
                        <?php else: ?>
                        <option selected>Độc thân</option>
                        <option>Đã kết hôn</option>
                        <?php endif; ?> 
                      <?php else: ?>           
                      <option selected>Độc thân</option>
                      <option>Đã kết hôn</option>
                      <?php endif; ?>
                </select>
              </div>

              <div class="form-group">
                <label for="job-region">Khu vực sinh sống</label>
                <select class="selectpicker border rounded" name="region" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn khu vực" required>
                      <?php $__currentLoopData = $city_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(!empty($hoso)): ?>
                      <option <?php echo e(strcasecmp($hoso->khuvuc,$city->Title) == 0?'selected':''); ?>><?php echo e($city->Title); ?></option>
                      <?php else: ?>
                      <option><?php echo e($city->Title); ?></option>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="form-group">
                <label for="job-type">Hình thức làm việc</label>
                <select name="status" class="selectpicker border rounded" id="job-type" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn hình thức làm việc" required>
                <?php if(!empty($hoso)): ?>
                  <?php if($hoso->trangthailv == 'Part Time'): ?>
                  <option selected>Part Time</option>                
                  <option>Full Time</option>                
                  <?php else: ?>
                  <option>Part Time</option>                
                  <option selected>Full Time</option> 
                  <?php endif; ?>
                <?php else: ?>
                  <option>Part Time</option>                
                  <option selected>Full Time</option> 
                <?php endif; ?>  
                </select>
              </div>


              <div class="form-group">
                <label for="job-description">Mục tiêu</label>
                <div class="editor" name="ASSA" id="editor-1">
                  <p>Write Job Description!</p>
                </div>                
              </div>

              <h3 class="text-black my-5 border-bottom pb-2">Thông tin thêm</h3>              
              <div class="form-group">
                <label for="company-tagline">Trình độ ngoại ngữ</label>
                <input type="text" class="form-control" id="company-tagline" placeholder="e.g. New York">
              </div>

              <div class="form-group">
                <label for="job-description">Trình độ tin học</label>
                <div class="editor" id="editor-2">
                  <p>Description</p>
                </div>
              </div>
              
              <div class="form-group">
                <label for="company-website">Sở trường</label>
                <input type="text" class="form-control" id="company-website" placeholder="https://">
              </div>
              
            </form>
          </div>

         
        </div>
        <div class="row align-items-center mb-5">
          
          <div class="col-lg-4 ml-auto">
            <div class="row">
              <div class="col-6">
                <a href="#" class="btn btn-block btn-light btn-md"><span class="icon-open_in_new mr-2"></span>Preview</a>
              </div>
              <div class="col-6">
                <a href="#" class="btn btn-block btn-primary btn-md"
                      onclick="event.preventDefault();
                           document.getElementById('profile').submit();"
                >
              Save Job
            </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>