
                <footer class="footer">
                     © 2020 HTP - All Rights Reserved.
                </footer>

            </div>
            <!-- End Right content here -->

        </div>
        
        <script src="<?php echo e(asset('admin\js\popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\modernizr.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\detect.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\fastclick.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\jquery.slimscroll.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\jquery.blockUI.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\waves.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\wow.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\jquery.nicescroll.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\jquery.scrollTo.min.js')); ?>"></script>

        <!--Morris Chart-->
        <script src="<?php echo e(asset('admin\plugins\morris\morris.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\plugins\raphael\raphael-min.js')); ?>"></script>

        <script src="<?php echo e(asset('admin\pages\dashborad.js')); ?>"></script>

        <script src="<?php echo e(asset('admin\js\app.js')); ?>"></script>
        <!-- END wrapper -->        
    </body>
</html>