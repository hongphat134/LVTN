<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Mẫu hồ sơ</h1>
            <div class="custom-breadcrumbs">
              <a href="#">Home</a> <span class="mx-2 slash">/</span>
              <a href="#">Job</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Mẫu hồ sơ</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    
    <section class="site-section">
      <div class="container">

        <div class="row align-items-center mb-5">
          <div class="col-lg-8 mb-4 mb-lg-0">
            <div class="d-flex align-items-center">
              <div>
                <h2>Mẫu hồ sơ</h2>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="row">
              <div class="col-6">
                <a href="#" class="btn btn-block btn-light btn-md"><span class="icon-open_in_new mr-2"></span>Xem trước</a>
              </div>
              <div class="col-6">
                <a href="#" class="btn btn-block btn-primary btn-md"
                    onclick="event.preventDefault();
                           document.getElementById('profile').submit();">
                Lưu mẫu
              </a>
              </div>
            </div>
          </div>
        </div>
        <div class="row mb-5">
          <div class="col-lg-12">
            <form id="profile" action="<?php echo e(url('/nguoitimviec/create-profile')); ?>" class="p-4 p-md-5 border rounded" method="post" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <h3 class="text-black mb-5 border-bottom pb-2">Thông tin hồ sơ</h3>
              
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="alert alert-danger alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
               <?php echo e($error); ?>

              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php if(session('error')): ?>
              <div class="alert alert-danger alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
               <?php echo e(session('error')); ?>

              </div>
              <?php endif; ?>
              
              <div class="form-group">
                <label for="company-website-tw d-block">Upload ảnh đại diện</label> <br>
                <label class="btn btn-primary btn-md btn-file">
                  Browse File<input type="file" name="hinhthe" hidden>
                </label>
              </div>

              <!-- PUBLIC -->
              <div class="custom-control custom-radio custom-control-inline">
                <input type="radio" class="custom-control-input" id="public" name="public" value="1">
                <label class="custom-control-label" for="public">Công khai để nhà tuyển dụng có thể tìm kiếm hồ sơ</label>
              </div>
             
              <div class="custom-control custom-radio custom-control-inline">
                <input type="radio" class="custom-control-input" id="private" name="public" value="0">
                <label class="custom-control-label" for="private">Không công khai và chỉ dùng để làm mẫu</label>
              </div>

              <div class="form-group">
                <label for="nae">Họ và tên:</label>
                <input type="text" name="name" class="form-control" id="name" placeholder="Nhập họ tên...." value="<?php echo e(old('name')); ?>" required>
              </div>

              <div class="form-group">
                <label for="email">Email liên hệ</label>
                <input type="email" name="email" class="form-control" id="email" placeholder="Nhập Email...." value="<?php echo e(old('email')); ?>" required>
              </div>

              <div class="form-group">
                <label for="job-title">Ngành nghề</label>
                <select class="selectpicker border rounded" name="title" id="title" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn ngành nghề" required>                
                      <?php $__currentLoopData = $job_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                      <option <?php echo e(strcasecmp(old('title'),$job) == 0?'selected':''); ?>><?php echo e($job); ?></option>                      
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <option value="other">Khác</option>
                </select>
              </div>

              <div class="form-group" id="other_title"
              <?php if(!old('other_title')): ?> style="display: none;"
              <?php endif; ?>>
                <label for="nae">Ngành nghề khác</label>
                <input type="text" name="other_title" class="form-control" placeholder="Nhập tên ngành nghề..." value="<?php echo e(old('other_title')); ?>" required>
              </div>

              <div class="form-group">
                <label for="job-region">Kĩ năng cá nhân</label>
                <select class="selectpicker border rounded" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" name="skill[]" title="Chọn kĩ năng..." multiple data-max-options="5">
                      <?php $__currentLoopData = $skill_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($skill->id); ?>"
				<?php if(is_array(old('skill'))): ?>                        
              	<?php echo e(in_array($skill->id,old('skill')) ? 'selected':''); ?>

              	<?php endif; ?>
                       >
                        <?php echo e($skill->ten); ?>

                      </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
              </div>

              <div class="form-group">
                <label for="job-region">Số năm kinh nghiệm</label>
                <select class="selectpicker border rounded" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" name="exp" title="Chọn kinh nghiệm...">
                      <?php $__currentLoopData = $exp_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option <?php echo e(old('exp') == $exp ? 'selected':''); ?>>
                        <?php echo e($exp); ?>

                      </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
              </div>
              
              <div class="form-group">
                <label for="job-title">Bằng cấp cao nhất</label>
                <select class="selectpicker border rounded" name="degree" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn bằng cấp" required>                
                      <?php $__currentLoopData = $degree_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degree_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   	<option <?php echo e(strcasecmp(old('degree'),$degree_list) == 0?'selected':''); ?>><?php echo e($degree_list); ?></option>                      
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="form-group">
                <label for="job-title">Cấp bậc cao nhất</label>
                <select class="selectpicker border rounded" name="rank" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn cấp bậc" required>                
                      <?php $__currentLoopData = $rank_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                          
                      <option <?php echo e(strcasecmp(old('rank'),$rank) == 0?'selected':''); ?>><?php echo e($rank); ?></option>                      
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="form-group">
                <label for="job-title">Tình trạng hôn nhân</label>
                <select class="selectpicker border rounded" name="marital_stt" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true">          
                      <option selected>Độc thân</option>
                      <option <?php echo e(old('marital_stt') == 'Đã kết hôn' ? 'selected': ''); ?>>Đã kết hôn</option>                      
                </select>
              </div>

              <div class="form-group">
                <label for="job-region">Khu vực sinh sống</label>
                <select class="selectpicker border rounded" name="region" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn khu vực" required>
                      <?php $__currentLoopData = $city_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                      <option <?php echo e(strcasecmp(old('region'),$city->Title) == 0?'selected':''); ?>><?php echo e($city->Title); ?></option>                      
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="form-group">
                <label for="job-type">Hình thức làm việc</label>
                <select name="status" class="selectpicker border rounded" id="job-type" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn hình thức làm việc" required>
                  <option selected>Part Time</option>                
                  <option <?php echo e(old('job-type') == 'Full Time' ? 'selected' : ''); ?>>Full Time</option>                              
                </select>
              </div>

<!--               <div class="form-group">
                <label for="job-description">Mục tiêu</label>
                <div class="editor" name="ASSA" id="editor-1">
                  <p>Write Job Description!</p>
                </div>                
              </div> -->

              <h3 class="text-black my-5 border-bottom pb-2">Trình độ ngoại ngữ</h3>              
              <div class="form-group">
                <label for="job-region">Ngoại ngữ</label>
                <select class="selectpicker border rounded" name="language[]" id="language" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn ngoại ngữ" required multiple>
                      <?php $__currentLoopData = $language_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option
                      <?php if(is_array(old('language'))): ?>
                      <?php echo e(in_array($language,old('language')) ? 'selected':''); ?>

                      <?php endif; ?>
                      >
                      <?php echo e($language); ?>

                      </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <option value="other"
                      <?php if(is_array(old('language'))): ?>
                      <?php echo e(in_array('other',old('language')) ? 'selected':''); ?>

                      <?php endif; ?>
                      >Ngôn ngữ khác
                      </option>
                </select>
              </div>

              <div class="form-group" id="other_language" 
              <?php if(old('other_language')): ?>
              <?php else: ?> style="display: none" 
              <?php endif; ?>>
                <label for="nae">Ngoại ngữ khác</label>
                <input type="text" name="other_language" class="form-control" placeholder="Nếu nhập nhiều, hãy nhập (VD: Anh,Pháp,Đức,...)" value="<?php echo e(old('other_language')); ?>" required>
              </div>
<!-- 
              <div class="form-group">
                <label for="job-region">Trình độ</label>
                <select class="selectpicker border rounded" name="region" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn khu vực" required>
                      <option>Sơ cấp</option>
                      <option>Trung cấp</option>
                      <option>Cao cấp</option>
                </select>
              </div> -->              
              <h3 class="text-black my-5 border-bottom pb-2">Trình độ tin học</h3>
              <div class="form-group">
                <label for="nae">Phần mềm</label>
                <select class="selectpicker border rounded" name="itech[]" id="itech" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn phần mềm" required multiple>
                      <?php $__currentLoopData = $itech_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option
                      <?php if(is_array(old('itech'))): ?>
                      <?php echo e(in_array($itech,old('itech')) ? 'selected':''); ?>

                      <?php endif; ?>
                      ><?php echo e($itech); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <option value="other"
                      <?php if(is_array(old('itech'))): ?>
                      <?php echo e(in_array('other',old('itech')) ? 'selected':''); ?>

                      <?php endif; ?>
                      >Phần mềm khác</option>
                </select>
              </div>

              <div class="form-group" id="other_itech"
              <?php if(old('other_itech')): ?>
              <?php else: ?> style="display: none" 
              <?php endif; ?>>
                <label for="nae">Phần mềm khác</label>
                <input type="text" name="other_itech" class="form-control" id="name" placeholder="Nhập tên phần mềm...(Access,Visio,Github,...)" value="<?php echo e(old('other_itech')); ?>" required>
              </div>

              <h3 class="text-black my-5 border-bottom pb-2">Mục tiêu nghề nghiệp</h3>
              <div class="form-group">
                  <textarea class="form-control" name="target" id="" cols="30" rows="10" placeholder="Nhập mục tiêu...."><?php echo e(old('target')); ?></textarea>
              </div>

              <h3 class="text-black my-5 border-bottom pb-2">Sở trường</h3>
              <div class="form-group">
                  <textarea class="form-control" name="talent" id="" cols="30" rows="10" placeholder="Nhập sở trường...."><?php echo e(old('talent')); ?></textarea>
              </div>
              
            </form>
          </div>

         
        </div>
        <div class="row align-items-center mb-5">
          
          <div class="col-lg-4 ml-auto">
            <div class="row">
              <div class="col-6">
                <a href="#" class="btn btn-block btn-light btn-md"><span class="icon-open_in_new mr-2"></span>Preview</a>
              </div>
              <div class="col-6">
                <a href="#" class="btn btn-block btn-primary btn-md"
                      onclick="event.preventDefault();
                           document.getElementById('profile').submit();"
                >
              Save Job
            </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <script src="<?php echo e(asset('js/profile.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>