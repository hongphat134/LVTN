<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Mẫu hồ sơ xin việc của <?php echo e($profile->hoten); ?></title>
	<!-- <link rel="stylesheet" href="<?php echo e(asset('css/custom-bs.css')); ?>"> -->
      
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<style>
		*{
			font-family: DejaVu Sans;			
		}
		table{
			width: 100%;	
			text-align: center;		
		}
		td:first-child{
			background-color: #EECFC4;
		}
	</style>
</head>
<body>	
	<h1 style="text-align: center;">Hồ sơ xin việc</h1>
	<div class="container">		
		<table border="1">
			<tr>
				<td>Họ tên</td>
				<td><?php echo e($profile->hoten); ?></td>
			</tr>
			<tr>
				<td>Email liên hệ</td>
				<td><?php echo e($profile->emaillienhe); ?></td>
			</tr>
			<tr>
				<td>Ngành nghề</td>
				<td><?php echo e($profile->nganh); ?></td>
			</tr>
			<tr>
				<td>Kĩ năng</td>
				<td>
					<?php $__currentLoopData = $profile->kinang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php echo e($skill->ten); ?> /
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>					
				</td>
			</tr>
			<tr>
				<td>Khu vực</td>
				<td><?php echo e($profile->khuvuc); ?></td>
			</tr>
			<tr>
				<td>Tình trạng hôn nhân</td>
				<td><?php echo e($profile->honnhan); ?></td>
			</tr>
			<tr>
				<td>Hình thức làm việc</td>
				<td><?php echo e($profile->trangthailv); ?></td>
			</tr>
			<tr>
				<td>Bằng cấp cao nhất</td>
				<td><?php echo e($profile->bangcap); ?></td>
			</tr>
			<tr>
				<td>Cấp bậc cao nhất</td>
				<td><?php echo e($profile->capbac); ?></td>
			</tr>
			<tr>
				<td>Kinh nghiệm</td>
				<td><?php echo e($profile->kinhnghiem); ?></td>
			</tr>
			<tr>
				<td>Ngoại ngữ</td>
				<td>
					<?php if($profile->ngoaingu): ?>
						<?php $__currentLoopData = json_decode($profile->ngoaingu); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php echo e($language); ?> &
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>					
				</td>
			</tr>
			<tr>
				<td>Tin học</td>
				<td>
					<?php if($profile->tinhoc): ?>
						<?php $__currentLoopData = json_decode($profile->tinhoc); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php echo e($itech); ?> $
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>	
				</td>
			</tr>
			<tr>
				<td>Mục tiêu</td>
				<td><?php echo e($profile->muctieu); ?></td>
			</tr>
			<tr>
				<td>Sở trường</td>
				<td><?php echo e($profile->sotruong); ?></td>
			</tr>
		</table>		
	</div>
</body>
</html>