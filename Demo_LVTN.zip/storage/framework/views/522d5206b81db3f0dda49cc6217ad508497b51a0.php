<!-- NAVBAR -->
<header class="site-navbar mt-3">
  <div class="container-fluid">
    <div class="row align-items-center">
      <div class="site-logo col-6"><a href="<?php echo e(url('/')); ?>">HTP is Mine</a></div>

      <nav class="mx-auto site-navigation">
        <ul class="site-menu js-clone-nav d-none d-xl-block ml-0 pl-0">
          <li><a href="<?php echo e(url('/')); ?>" class="nav-link active">Home</a></li>
          <li><a href="about.html">About</a></li>
          <li class="has-children">
            <a href="<?php echo e(route('jobListings')); ?>">Profile Listings</a>
            <ul class="dropdown">
              <li><a href="job-single.html">Job Single</a></li>
              <li><a href="post-job.html">Post a Job</a></li>
            </ul>
          </li>
          <li class="has-children">
            <a href="services.html">Pages</a>
            <ul class="dropdown">
              <li><a href="services.html">Services</a></li>
              <li><a href="service-single.html">Service Single</a></li>
              <li><a href="blog-single.html">Blog Single</a></li>
              <li><a href="portfolio.html">Portfolio</a></li>
              <li><a href="portfolio-single.html">Portfolio Single</a></li>
              <li><a href="testimonials.html">Testimonials</a></li>
              <li><a href="faq.html">Frequently Ask Questions</a></li>
              <li><a href="gallery.html">Gallery</a></li>
            </ul>
          </li>
          <li><a href="blog.html">Blog</a></li>
          <li><a href="contact.html">Contact</a></li>
                    
          <li class="has-children">
            <a href="#" class="d-lg-none">Hi, <?php echo e(Auth::user()->ten); ?></a>
            <ul class="dropdown">
              <li><a href="<?php echo e(route('postJob')); ?>"><span class="mr-2">+</span> Đăng tin tuyển dụng</a></li>
              <li><a href="<?php echo e(url('/nhatuyendung/jobs-list')); ?>">Danh sách tin</a></li>
              <li><a href="<?php echo e(route('savePf')); ?>">Hồ sơ đã lưu</a></li>
              <li><a href="<?php echo e(route('appliedPf')); ?>">Hồ sơ đã ứng tuyển</a></li>
              <li><a href="#">Thông báo hồ sơ phù hợp</a></li>
              <li><a href="javascript:void(0)" data-toggle="modal" data-target="#myModal" href="javascript:void(0)" id="open">Cập nhật tài khoản</a></li>
              <li><a href="<?php echo e(url('nhatuyendung/profile')); ?>">Chỉnh sửa hồ sơ</a></li>              
              <li>
                <a href="javascript:void(0)" class="d-lg-none"
                      onclick="event.preventDefault();
                               document.getElementById('logout-form').submit();">
                                        Đăng xuất
                </a>                
              </li>   
            </ul>
          </li>                                                                         
        </ul>
      </nav>
      
      <div class="right-cta-menu text-right d-flex aligin-items-center col-6">
        <div class="ml-auto">                           
          <div class="dropdown dropleft"> 
            <button type="button" class="btn btn-primary border-width-2 d-none d-lg-inline-block dropdown-toggle" data-toggle="dropdown">
              Hi, <?php echo e(Auth::user()->ten); ?>

            </button>
            <div class="dropdown-menu">
              <h5 class="dropdown-header">TIN TUYỂN DỤNG</h5>
              <a class="dropdown-item" href="<?php echo e(route('postJob')); ?>">Đăng tin</a>
              <a class="dropdown-item" href="<?php echo e(url('/nhatuyendung/jobs-list')); ?>">Danh sách tin</a>

              <h5 class="dropdown-header">QUẢN LÝ ỨNG VIÊN</h5>
              <a class="dropdown-item" href="<?php echo e(route('savePf')); ?>">Hồ sơ đã lưu</a>
              <a class="dropdown-item" href="<?php echo e(route('appliedPf')); ?>">Hồ sơ đã ứng tuyển</a>
              <a class="dropdown-item" href="#">Thông báo hồ sơ phù hợp</a>
              <h5 class="dropdown-header">TÀI KHOẢN</h5>
              <a class="dropdown-item" data-toggle="modal" data-target="#myModal" href="javascript:void(0)" id="open">Cập nhật tài khoản</a>
              <a class="dropdown-item" href="<?php echo e(url('nhatuyendung/profile')); ?>">Chỉnh sửa hồ sơ</a>
              <a class="dropdown-item" href="javascript:void(0)"
                  onclick="event.preventDefault();
                             document.getElementById('logout-form').submit();">
              Đăng xuất
              </a>
            </div>
          </div>                

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo e(csrf_field()); ?>

          </form>                      
        </div>
        <a href="#" class="site-menu-toggle js-menu-toggle d-inline-block d-xl-none mt-lg-2 ml-3"><span class="icon-menu h3 m-0 p-0 mt-2"></span></a>        
      </div>                
    </div>
  </div>  
</header>
  <div class="site-wrap">
    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->

    <div class="modal fade" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      
      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Thông tin tài khoản</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>                  
      </div>
      <?php if(session('user-success')): ?>
      <div class="alert alert-success alert-dismissible fade show">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <?php echo e(session('user-success')); ?>

      </div>
      <?php elseif(session('user-warning')): ?>
      <div class="alert alert-warning alert-dismissible fade show">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <?php echo e(session('user-warning')); ?>

      </div>
      <?php endif; ?>
      <form id="change-name" action="<?php echo e(url('user/change-name')); ?>" method="post">
      <?php echo e(csrf_field()); ?>

      <!-- Modal body -->
      <div class="modal-body"> 
      <div class="<?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
          <label for="">Tên tài khoản</label>
          <input type="text" name="name" class="form-control"  value="<?php echo e(old('name')); ?>"
         placeholder="Nhập tên...." required> 
          <?php if($errors->has('name')): ?>
          <span class="help-block">
              <strong><?php echo e($errors->first('name')); ?></strong>
          </span>
          <?php endif; ?>
      </div>       
        
      </div>
      </form> 
      
      <!-- Modal footer -->
      <div class="modal-footer">                  
        <button type="submit" class="btn btn-info"
        onclick="event.preventDefault();
               document.getElementById('change-name').submit();">
        Đổi tên tài khoản
        </button>                                   
      </div>                

      <div class="modal-header">
        <h4 class="modal-title">Đổi mật khẩu</h4>                  
      </div>
      
      <form id="change-pwd" action="<?php echo e(url('user/change-pwd')); ?>" method="post">
      <?php echo e(csrf_field()); ?>

      <!-- Modal body -->
      <div class="modal-body">                  
          <?php echo e(csrf_field()); ?>   

          <?php if(empty(Auth::user()->email)): ?>    
          <div class="<?php echo e(session('user-error') ? 'has-error' : ''); ?>">
            <label for="email">Email</label>
            <input type="email" name="email" class="form-control" placeholder="Nhập email..." required>
            <?php if(session('user-error')): ?>
            <span class="help-block">
                <strong><?php echo e(session('user-error')); ?></strong>
            </span>
            <?php endif; ?>
          </div>
          <?php endif; ?>  

          <?php if(!empty(Auth::user()->password)): ?>    
          <div class="<?php echo e(session('user-error') ? 'has-error' : ''); ?>">
            <label for="">Mật khẩu cũ</label>
            <input type="password" name="old_password" class="form-control" placeholder="Nhập mật khẩu cũ..." required>
            <?php if(session('user-error')): ?>
            <span class="help-block">
                <strong><?php echo e(session('user-error')); ?></strong>
            </span>
            <?php endif; ?>
          </div>
          <?php endif; ?>

          <div class="<?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
            <label for="">Mật khẩu mới</label>
            <input type="password" name="password" class="form-control" placeholder="Nhập mật khẩu mới..." required>
            <?php if($errors->has('password')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
            <?php endif; ?>
          </div>
          
          
            <label for="">Nhập lại mật khẩu</label>
            <input type="password" name="password_confirmation" class="form-control" placeholder="Nhập lại mật khẩu mới..." required>      
          
      </div>
      </form>
      <!-- Modal footer -->
      <div class="modal-footer">                  
        <button type="submit" class="btn btn-info"
        onclick="event.preventDefault();
               document.getElementById('change-pwd').submit();">
        Đổi mật khẩu
        </button>                                            
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
      </div>                
    </div>
           
  </div>
</div>          
<?php echo e(session('user-warning')); ?>         
<?php if(session('user-success') || session('user-error') || session('user-warning') ): ?>
<script>
  $(document).ready(function(){
    $("#open").trigger('click');
  });
</script>
<?php endif; ?>