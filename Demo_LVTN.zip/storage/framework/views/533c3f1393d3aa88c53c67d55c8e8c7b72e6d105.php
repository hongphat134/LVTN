<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Chọn hình thức ứng tuyển</h1>
            <div class="custom-breadcrumbs">
              <a href="#">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Chọn hình thức ứng tuyển</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    
    <section class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 mb-5">
            <h2 class="mb-4 text-center">Tủ hồ sơ</h2>
            <?php if(!empty($profiles->toArray())): ?>
            <form class="p-4 border rounded" method="get" 
            action="<?php echo e(url('/nguoitimviec/nop-ho-so')); ?>">
            	<?php if(session('error')): ?>
    					<div class="alert alert-danger alert-dismissible fade show">
    					  <button type="button" class="close" data-dismiss="alert">&times;</button>
    					  <?php echo e(session('error')); ?>

    					</div>            		
            	<?php endif; ?>
				
            	<?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<div class="p-4 border rounded">
            		<h4><input type="radio" name="profile" value="<?php echo e($profile->id); ?>"> <?php echo e($profile->nganh); ?></h4>
					
    					<span class="col-3">
    						<label for="lname">Trình độ: <?php echo e($profile->bangcap); ?></label>
    					</span> 
    					<span class="col-3">
    						<label for="lname">Kinh nghiệm: <?php echo e($profile->kinhnghiem); ?></label>
    					</span>            		
    					<span class="col-3">
    						<label for="lname">Tỉnh thành phố: <?php echo e($profile->khuvuc); ?></label>
    					</span> 
    					<span class="col-3">
    						<label for="lname">Cập nhật: <?php echo e(date('d/m/Y',strtotime($profile->updated_at))); ?></label>
              </span> 
            	</div> 
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<input type="hidden" value="<?php echo e($news_id); ?>" name="ttd_id">
            	<button class="btn btn-primary float-right">Nộp hồ sơ</button>
            </form>
            <?php endif; ?> 
            <a href="<?php echo e(route('apply',$news_id)); ?>"><button class="btn btn-danger">Tạo hồ sơ mới</button></a>
            	<a href="#"><button class="btn btn-danger">Copy hồ sơ</button></a>
             

          </div>                                        
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>