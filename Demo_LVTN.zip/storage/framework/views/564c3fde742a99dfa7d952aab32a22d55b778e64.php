<?php $__env->startSection('content'); ?>
    <!-- MODAL FORM DELETE -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Xoá mẫu hồ sơ</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            Bạn có chắc chắn muốn xoá mẫu hồ sơ này không?
          </div>
          <div class="modal-footer">
            <a id="delete" href="#"><button type="button" class="btn btn-primary">Đồng ý</button></a>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
          </div>
        </div>
      </div>
    </div>

    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Tủ hồ sơ</h1>
            <div class="custom-breadcrumbs">
              <a href="#">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Tủ hồ sơ</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section services-section bg-light block__62849">
      <div class="container">
        <?php if(session('success')): ?>
         <div class="alert alert-success alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Hoàn tất!</strong> <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        
        <div class="row">
          <?php $__currentLoopData = $profile_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-6 col-md-6 col-lg-4 mb-4 mb-lg-5">
            <?php if($profile->trangthai == 0): ?>
            <a href="<?php echo e(url('/nguoitimviec/update-profile',$profile->id)); ?>" class="block__16443 text-center d-block">              
            <?php else: ?>
            <a href="javascript:void(0)" class="block__16443 text-center d-block">
              <div class="ribbon-wrapper">
                <div class="ribbon red">Duyệt</div>  
              </div>              
            <?php endif; ?>

            <?php if($profile->congkhai == 1): ?>
            <div class="ribbon-right-wrapper">
                <div class="ribbon-right blue">public</div>  
              </div>
            <?php endif; ?>
              <span class="custom-icon mx-auto"><span class="icon-file-text d-block"></span></span>
              <h3>Mẫu hô sơ <?php echo e($key + 1); ?></h3>
              <p>Họ tên: <?php echo e($profile->hoten); ?></p>
              <p>Ngành nghề: <?php echo e($profile->nganh); ?></p>              
              <p>Khu vực: <?php echo e($profile->khuvuc); ?></p>  
              <p>Ngày cập nhật: <?php echo e(date('d/m/Y',strtotime($profile->updated_at))); ?></p>            
            </a>

            <div class="row">
              <span class="col-7">
                <div class="dropdown">
  <button class="btn btn-outline-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <i class="icon-th-large"></i> Quản lý mẫu hồ sơ
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" data-toggle="modal" data-target="#viewModal<?php echo e($key); ?>" href="javascript:void(0)">Xem mẫu</a>
    <a class="dropdown-item" href="<?php echo e(route('pdf-profile',$profile->id)); ?>" target="_blank">Xuất PDF</a>
    <a class="dropdown-item call-delete" id="<?php echo e($profile->id); ?>" data-toggle="modal" data-target="#deleteModal" href="javascript:void(0)">Xoá</a>
  </div>
</div>
              <!-- <button class="btn btn-outline-success" data-toggle="modal" data-target="#viewModal<?php echo e($key); ?>"><i class="icon-search"></i> XEM</button> -->
              </span>
              <span class="col-5">                
              <a href="<?php echo e(url('/nguoitimviec/set-status',$profile->id)); ?>"><button class="btn btn-outline-info"><i class="icon-public"></i> <?php echo e($profile->congkhai == 0 ? 'Bật':'Tắt'); ?> Public</button></a>
              </span> 
              <!-- <span class="col-4">              
              <button id="<?php echo e($profile->id); ?>" class="btn btn-outline-danger call-delete" data-toggle="modal" data-target="#deleteModal"><i class="icon-trash"></i> XOÁ</button>
              </span>                  -->
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <script>
            $(".call-delete").click(function(){
                // console.log($(this).attr('id'));
                var id = $(this).attr('id');
                          
                $("#delete").attr('href', '/nguoitimviec/delete-profile/' + id);
            });
          </script>    
        </div>
        <!-- ROW -->
      </div>
      <!-- CONTAINER -->
    </section>
  
  <!-- VIEW PROFILE -->
  <?php $__currentLoopData = $profile_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <!-- MODAL FORM VIEW -->
    <div class="modal fade" id="viewModal<?php echo e($key); ?>" tabindex="-1">
      <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">          
          <div class="row">
          <div class="col-lg-4 mr-auto">
            <div class="border p-3 rounded">
              <ul class="list-unstyled block__47528 mb-0">
                <li><span class="active"><h3><?php echo e($profile->nganh); ?></h3></span></li>
                <li>Họ & tên: <a href="#"><?php echo e($profile->hoten); ?></a></li>
                <li>Email: <a href="#"><?php echo e($profile->emaillienhe); ?></a></li>
                <li>Khu vực: <a href="#"><?php echo e($profile->khuvuc); ?></a></li>
                <li>Hôn nhân: <a href="#"><?php echo e($profile->honnhan); ?></a></li>
                <li>Hình thức: <a href="#"><?php echo e($profile->trangthailv); ?></a></li>
                <li>Bằng cấp: <a href="#"><?php echo e($profile->bangcap); ?></a></li>
                <li>Cấp bậc: <a href="#"><?php echo e($profile->capbac); ?></a></li>
                <li>Kinh Nghiệm: <a href="#"><?php echo e($profile->kinhnghiem); ?></a></li>              
                <li>Trạng thái: <a href="#"><?php echo e($profile->trangthai == 1 ? 'Công khai': 'Chưa công khai'); ?></a></li>              
              </ul>
            </div>
          </div>
          <div class="col-lg-8">
            <span class="text-primary d-block mb-5">
              <span class="icon-search display-1"></span>
              <span class="icon-star display-1"></span>
              <span class="icon-files-o display-1"></span>
              <span class="icon-file-text-o display-1"></span>
              <span class="icon-file-text display-1"></span>
              <span class="icon-file display-1"></span>
              <span class="icon-file-word-o display-1"></span>
              <span class="icon-insert_drive_file display-1"></span>
            </span>
            <h2 class="mb-4">Mục tiêu</h2>
            <p>
              <?php echo nl2br($profile->muctieu); ?>

            </p>           
            <h2 class="mb-4">Trình độ ngoại ngữ</h2>
            <p>
              <?php if($profile->ngoaingu): ?>              
              <?php $__currentLoopData = json_decode($profile->ngoaingu); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($language); ?> <strong>&</strong>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                Chưa có ngoại ngữ!
              <?php endif; ?>
            </p>           
            <h2 class="mb-4">Trình độ tin học</h2>
            <p>
              <?php if($profile->tinhoc): ?>
              <?php $__currentLoopData = json_decode($profile->tinhoc); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($itech); ?> <strong>&</strong>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                Không có!
              <?php endif; ?>
            </p>     
            <h2 class="mb-4">Sở trường</h2>
            <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam dolorum incidunt dolorem facere, officiis placeat consequuntur odit quasi, quam voluptates, deleniti! Neque tenetur in, omnis consectetur molestias expedita nostrum et.</p> <-->
            <p>
              <?php echo nl2br($profile->sotruong); ?>

            </p>            
            <p>
              <a href="#" class="btn btn-primary btn-md mt-4"><?php echo e($profile->created_at); ?></a>
              <a href="#" class="btn btn-primary btn-md mt-4"><?php echo e($profile->updated_at); ?></a>
            </p>

          </div>
        </div>
          <div class="modal-footer">           
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>