Chào bạn, <?php echo e($user->ho.' '.$user->ten); ?>!</br>
Chúng tôi đã nhận được ý kiến từ bạn!</br>

Tiêu đề: <?php echo e($user->tieude); ?> </br>
Lời nhắn: <?php echo e($user->noidung); ?> </br>
<hr>

Chúng tôi xin giải đáp vấn đề này là:
<?php echo e($repond); ?>

<hr>

Cảm ơn bạn đã quan tâm và sử dụng dịch vụ của chúng tôi!