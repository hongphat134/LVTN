<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- MENU -->
    <?php echo $__env->make('ntd_layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- SEARCH -->
    <?php echo $__env->make('ntd_layouts.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- HOME -->
    <section class="site-section" id="next">
      <div class="container">

        <div class="row mb-5 justify-content-center">
          <div class="col-md-7 text-center">
            <h2 class="section-title mb-2"><?php echo e($job_listings->total()); ?> tin tuyển dụng đã đăng</h2>
          </div>
        </div>
        
        <ul class="job-listings mb-5">
          <?php $__currentLoopData = $job_listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="job-listing d-block d-sm-flex pb-3 pb-sm-0 align-items-center">
            <?php if($news->congkhai == 1): ?>
            <div class="ribbon-wrapper">
                <div class="ribbon green">Duyệt</div>  
            </div>
            <!-- Duyệt r` thì k dc sửa -->
            <a href="javascript:void(0)"></a>
            <?php else: ?>
            <a href="#"></a>                       
            <?php endif; ?>
            
            <div class="job-listing-logo">
              <img src="<?php echo e(url('logo/'.$news->hinh)); ?>" alt="Free Website Template by Free-Template.co" class="img-fluid">
            </div>

            <div class="job-listing-about d-sm-flex custom-width w-100 justify-content-between mx-4">
              <div class="job-listing-position custom-width w-50 mb-3 mb-sm-0">
                <h2>
                  <?php echo e($news->nganh); ?>

                  <span class="badge badge-danger">Loại tin: tin miễn phí</span>
                </h2>
                <strong>Ngày cập nhật: <?php echo e(date('d/m/Y',strtotime($news->updated_at))); ?></strong>
                <div class="keywords">
                  <?php $__currentLoopData = $news->kinang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <button class="btn btn-outline-info"><?php echo e($skill); ?></button>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                  
                </div>                
              </div>
              <div class="job-listing-location mb-3 mb-sm-0 custom-width w-25">
                <?php $__currentLoopData = json_decode($news->tinhthanhpho); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="icon-room"></span><?php echo e($city); ?></br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="job-listing-meta">
                <?php if($news->trangthailv == 'Part Time'): ?>
                <span class="badge badge-danger"><?php echo e($news->trangthailv); ?></span>
                <?php else: ?>
                <span class="badge badge-success"><?php echo e($news->trangthailv); ?></span>
                <span class="badge badge-pill badge-light text-dark">
                  <?php echo e($news->congkhai == 1 ? 'Công khai' : 'Đã ẩn'); ?>

                </span>
                <?php endif; ?>
                </br>
                <span class="badge badge-info">Hạn tuyển dụng</span>
                <span class="badge badge-danger">
                  <?php echo e(date('d/m/Y',strtotime($news->hantuyendung))); ?>

                </span>                              
                </br>
                <span class="badge badge-dark">Lượt nộp: 0</span>
                <span class="badge badge-warning text-dark">Lượt xem: 0</span>
              </div>               
            </div>  

          </li>
          <div class="form-row">
            <div class="col">
            <form action="<?php echo e(url('nhatuyendung/delete-job/'.$news->id)); ?>" method="post">
              <button type="submit" class="btn btn-outline-danger form-control">
              <i class="icon-trash"></i>  XOÁ
              </button>
              <?php echo method_field('delete'); ?>

              <?php echo csrf_field(); ?>

            </form>
            </div>
            <div class="col">
              <a href="<?php echo e(route('updateJob',$news->id)); ?>"><button class="btn btn-outline-success form-control"><i class="icon-search"></i> CẬP NHẬT</button></a>
            </div>            
          </div>
          <!-- <button class="btn btn-outline-danger form-control">XOÁ</button>           -->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </ul>

        <div class="row pagination-wrap">
          <div class="col-md-6 text-center text-md-left mb-4 mb-md-0">
            <span>Showing 1-<?php echo e($job_listings->perPage()); ?> trong <?php echo e($job_listings->total()); ?> công việc</span>
          </div>
          <?php echo $__env->make('layouts.paginating', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

      </div>
    </section>

    <?php echo $__env->make('layouts.looking-job', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>