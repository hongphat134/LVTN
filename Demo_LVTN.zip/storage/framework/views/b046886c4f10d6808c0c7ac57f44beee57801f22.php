<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Thông tin hồ sơ xin việc</h1>
            <div class="custom-breadcrumbs">
              <a href="<?php echo e(url('/')); ?>">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Thông tin hồ sơ xin việc</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section block__18514" id="next-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 mr-auto">
            <div class="border p-3 rounded">
              <ul class="list-unstyled block__47528 mb-0">
                <li><span class="active"><h3><?php echo e($profile->nganh); ?></h3></span></li>
                <li>Họ & tên: <a href="#"><?php echo e($profile->hoten); ?></a></li>
                <li>Email: <a href="#"><?php echo e($profile->emaillienhe); ?></a></li>
                <li>Khu vực: <a href="#"><?php echo e($profile->khuvuc); ?></a></li>
                <li>Hôn nhân: <a href="#"><?php echo e($profile->honnhan); ?></a></li>
                <li>Hình thức: <a href="#"><?php echo e($profile->trangthailv); ?></a></li>
                <li>Bằng cấp: <a href="#"><?php echo e($profile->bangcap); ?></a></li>
                <li>Cấp bậc: <a href="#"><?php echo e($profile->capbac); ?></a></li>
                <li>Kinh Nghiệm: <a href="#"><?php echo e($profile->kinhnghiem); ?></a></li>                              
              </ul>
            </div>
          </div>
          <div class="col-lg-8">
            <span class="text-primary d-block mb-5">
              <span class="icon-search display-1"></span>
              <span class="icon-star display-1"></span>
              <span class="icon-files-o display-1"></span>
              <span class="icon-file-text-o display-1"></span>
              <span class="icon-file-text display-1"></span>
              <span class="icon-file display-1"></span>
              <span class="icon-file-word-o display-1"></span>
              <span class="icon-insert_drive_file display-1"></span>
            </span>
            
            <h2 class="mb-4">Mục tiêu</h2>
            <p>
              <?php echo nl2br($profile->muctieu); ?>

            </p>           
            <h2 class="mb-4">Trình độ ngoại ngữ</h2>
            <p>
              <?php if($profile->ngoaingu): ?>              
              <?php $__currentLoopData = json_decode($profile->ngoaingu); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($language); ?> <strong>&</strong>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                Chưa có ngoại ngữ!
              <?php endif; ?>
            </p>           
            <h2 class="mb-4">Trình độ tin học</h2>
            <p>
              <?php if($profile->tinhoc): ?>
              <?php $__currentLoopData = json_decode($profile->tinhoc); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($itech); ?> <strong>&</strong>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                Không có!
              <?php endif; ?>
            </p>     
            <h2 class="mb-4">Sở trường</h2>
            <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam dolorum incidunt dolorem facere, officiis placeat consequuntur odit quasi, quam voluptates, deleniti! Neque tenetur in, omnis consectetur molestias expedita nostrum et.</p> <-->
            <p>
              <?php echo nl2br($profile->sotruong); ?>

            </p>            
            <p>
              <a href="#" class="btn btn-primary btn-md mt-4"><?php echo e($profile->created_at); ?></a>
              <a href="#" class="btn btn-danger btn-md mt-4">Ứng tuyển</a>
            </p>

          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>