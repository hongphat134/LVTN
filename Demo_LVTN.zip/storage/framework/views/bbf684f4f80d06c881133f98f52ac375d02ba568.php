<?php if($job_listings->lastPage() != 1 && $job_listings->currentPage() <= $job_listings->lastPage()): ?>
<div class="col-md-6 text-center text-md-right">
	<div class="custom-pagination ml-auto">
		<?php if($job_listings->currentPage() != 1): ?>		
		<a href="<?php echo e($job_listings->url($job_listings->currentPage() - 1)); ?>" class="prev">Trước</a>
		<?php endif; ?>
		<div class="d-inline-block">
		<?php for($i = 1; $i <=  $job_listings->lastPage(); $i++): ?>
		
		<?php if($job_listings->currentPage() == $i): ?>
		<a class="active" href="javascript:void(0)"><?php echo $i; ?></a>

		<?php elseif(($i == $job_listings->currentPage() - 1 || $i == $job_listings->currentPage() - 2 || $i == $job_listings->currentPage() + 1 || $i == $job_listings->currentPage() + 2) || $i == $job_listings->lastPage() || $i == 1): ?>
		<a href="<?php echo e($job_listings->url($i)); ?>"><?php echo $i; ?></a>
		
		<?php elseif(($i == $job_listings->lastPage() - 1 || $i == 2) && $job_listings->lastPage() > 5): ?>
            <sub><i class="icon-ellipsis-h"></i></sub>
				
		<?php endif; ?>
		<?php endfor; ?>
		</div>		
		<?php if($job_listings->currentPage() != $job_listings->lastPage()): ?>        
        <a href="<?php echo e($job_listings->url($job_listings->currentPage() + 1)); ?>" class="next">Sau</a>                 
        <?php endif; ?>
	</div>
</div>
<?php endif; ?>

