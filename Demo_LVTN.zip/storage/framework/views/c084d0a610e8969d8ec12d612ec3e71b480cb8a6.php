<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Thông tin tuyển dụng <h3></h3></title>
      
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<style>
		*{
			font-family: DejaVu Sans;
		}		
	</style>
</head>
<body>	
	<h1 style="text-align: center;">Thông tin tuyển dụng (ID: <?php echo e($job->id); ?> )</h1>
	<div class="container">
		<div>
			Kĩ năng:
			<?php $__currentLoopData = $job->kinang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php echo e($skill->ten); ?> &
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div>
			Ngành: <?php echo e($job->nganh); ?>

		</div>
		<div>
			Mức lương: <?php echo e($job->mucluong); ?>

		</div>
		<div>
			Số lượng cần tuyển: <?php echo e($job->soluong); ?>

		</div>
		<div>
			Bằng cấp yêu cầu: <?php echo e($job->bangcap); ?>

		</div>	
		<div>
			Cấp bậc yêu cầu: <?php echo e($job->capbac); ?>

		</div>
		<div>
			Hình thức làm việc: <?php echo e($job->trangthailv); ?>

		</div>		
		<div>
			Khu vực làm việc:
			<?php $__currentLoopData = json_decode($job->tinhthanhpho); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php echo e($city); ?> $
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div>
			Yêu cầu giới tính: <?php echo e($job->gioitinh); ?>

		</div>
		<div>
			Yêu cầu kinh nghiệm: <?php echo e($job->kinhnghiem); ?>

		</div>
		<div>
			Hạn tuyển dụng: <?php echo e($job->hantuyendung); ?>

		</div>
		<div>
			Quyền lợi: <?php echo e($job->quyenloi); ?>

		</div>
		<div>
			Mô tả công việc: <?php echo e($job->motacv); ?>

		</div>
		<div>
			Ngày tạo: <?php echo e($job->created_at); ?>

		</div>
		<div>
			Ngày cập nhật: <?php echo e($job->updated_at); ?>

		</div>
	</div>	
</body>
</html>