<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Danh sách hồ sơ đã ứng tuyển</h1>
            <div class="custom-breadcrumbs">
              <a href="#">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Hồ sơ đã ứng tuyển</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <section class="site-section services-section bg-light block__62849" id="next-section">
      <div class="container">
        <?php if(!empty($profile_list)): ?>
        <div class="row">
          <?php $__currentLoopData = $profile_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-6 col-md-6 col-lg-4 mb-4 mb-lg-5">            
            <a href="<?php echo e(url('/nhatuyendung/view-profile',[$profile->idUser,$profile->idTTD])); ?>" class="block__16443 text-center d-block">
              <?php if($profile->new == 1): ?>
              <div class="ribbon-wrapper">
                <div class="ribbon red">Mới</div>
              </div>
              <?php endif; ?>
              <span class="custom-icon mx-auto"><span class="icon-file-text d-block"></span></span>
              <h3><?php echo e($profile->hoten); ?></h3>
              <p><?php echo e($profile->nganh); ?></p>
              <p><?php echo e($profile->khuvuc); ?></p>
              <p><?php echo e(date('d/m/Y',strtotime($profile->created_at))); ?></p>
              <p>
                Thuộc tin tuyển dụng có tiêu đề </br>
                <span class="badge badge-danger"><?php echo e($profile->title); ?></span>
              </p>
            </a>

          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
        </div>  
        
        <!-- Phân trang chưa truyền biến dc :( -->
        <div class="row pagination-wrap">
          <div class="col-md-6 text-center text-md-left mb-4 mb-md-0">
            <span>Showing 1-7 Of 43,167 Jobs</span>
          </div>
          <?php echo $__env->make('layouts.paginating',['job_listings' => $profile_list], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <?php else: ?>
        Không có tin nào cả!   
        <?php endif; ?>   
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ntd_layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>