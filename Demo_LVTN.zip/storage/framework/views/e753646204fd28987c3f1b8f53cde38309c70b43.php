<?php $__env->startComponent('mail::message'); ?>
# Thông báo

Xin chào, bạn có 1 hồ sơ xin việc mới.

<?php $__env->startComponent('mail::button', ['url' => 'http://lvtn.laravel.info/nhatuyendung/applied-profile-list', 'color' => 'green']); ?>
Xem ngay
<?php echo $__env->renderComponent(); ?>

Cảm ơn đã sử dụng dịch vụ của chúng tôi,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
