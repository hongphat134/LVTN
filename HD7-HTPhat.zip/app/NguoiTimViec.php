<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NguoiTimViec extends Model
{
    //
    protected $table = 'nguoitimviec';
    public $timestamps = true;

    // protected $primaryKey = 'idUser';
}
