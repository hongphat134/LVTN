@include('admins.layouts.header')

@include('admins.layouts.menu')

@yield('content')

@include('admins.layouts.footer')