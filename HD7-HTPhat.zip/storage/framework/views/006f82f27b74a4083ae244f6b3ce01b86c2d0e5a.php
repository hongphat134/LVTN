<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold"><?php echo e($news->nganh); ?></h1>
            <div class="custom-breadcrumbs">
              <a href="#">Home</a> <span class="mx-2 slash">/</span>
              <a href="#">Job</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong><?php echo e($news->nganh); ?></strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <section class="site-section">
      <div class="container">
        <div class="row align-items-center mb-5">
          <div class="col-lg-8 mb-4 mb-lg-0">
            <div class="d-flex align-items-center">
              <div class="border p-2 d-inline-block mr-3 rounded">                
              <?php if($owner->hinh): ?>
              <a href="<?php echo e(url('/thong-tin-ntd',$owner->idUser)); ?>"><img src="<?php echo e(asset('logo/'.$owner->hinh)); ?>" alt="Image" style="width: 200px; height: 200px"></a>
              <?php else: ?>
              <a href="<?php echo e(url('/thong-tin-ntd',$owner->idUser)); ?>"><img src="<?php echo e(asset('logo/default.png')); ?>" alt="Image"></a>
              <?php endif; ?>
                
              </div>
              <div>
                <h2>
                  <?php echo e($news->nganh); ?>

                <?php if(Auth::check()): ?>
                  <?php if(Auth::user()->theodoi_ntd): ?>
                    <?php if(in_array($owner->idUser,json_decode(Auth::user()->theodoi_ntd))): ?>
                    <a href="javascript:void(0)" id="<?php echo e($owner->idUser); ?>" class="btn btn-danger theo-doi">ĐANG THEO DÕI</a>  
                    <?php else: ?>
                    <a href="javascript:void(0)" id="<?php echo e($owner->idUser); ?>" class="btn btn-outline-danger theo-doi follow-rec">THEO DÕI</a>
                    <?php endif; ?>
                  <?php else: ?>
                  <a href="javascript:void(0)" id="<?php echo e($owner->idUser); ?>" class="btn btn-outline-danger theo-doi follow-rec">THEO DÕI</a>
                  <?php endif; ?>
                <script src="<?php echo e(url('ajax/follow-recruiters.js')); ?>"></script>
                <?php endif; ?>
                </h2>
                <div>
                  <span class="ml-0 mr-2 mb-2"><span class="icon-briefcase mr-2"></span>Nhà tuyển dụng <?php echo e($owner->ten); ?></span>
                  <span class="m-2"><span class="icon-clock-o mr-2"></span><span class="text-primary"><?php echo e($news->hinhthuc_lv); ?></span></span></br>
                  <?php $__currentLoopData = json_decode($news->tinhthanhpho); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="ml-0 mr-2 mb-2"><span class="icon-room mr-2"></span><?php echo e($city); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
                  <hr class="hr-text" data-content="Yêu cầu kĩ năng">
                  <div class="keywords">
                  <?php $__currentLoopData = json_decode($news->kinang); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <button class="btn btn-outline-info btn-sm"><?php echo e($skill); ?></button>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
                  </div>   
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="row">
              <div class="col-6 follow">
              <?php if(Auth::check()): ?> 
                <?php if(!empty(Auth::user()->theodoi)): ?>
                  <?php if(in_array($news->id,json_decode(Auth::user()->theodoi))): ?>
                  <a href="javascript:void(0)" id="<?php echo e($news->id); ?>" class="btn btn-block btn-dark btn-md">
                  <span class="icon-heart mr-2 text-danger"></span>
                  Đang theo dõi
                  </a>   
                  <?php else: ?>             
                  <a href="javascript:void(0)" id="<?php echo e($news->id); ?>" class="btn btn-block btn-light btn-md follow-news">
                  <span class="icon-heart-o mr-2 text-danger"></span>
                  Theo dõi tin tuyển dụng
                  </a>  
                  <?php endif; ?>                          
                <?php else: ?>
                <a href="javascript:void(0)" id="<?php echo e($news->id); ?>" class="btn btn-block btn-light btn-md follow-news">
                  <span class="icon-heart-o mr-2 text-danger"></span>
                  Theo dõi tin tuyển dụng
                </a>
                <?php endif; ?>
              <?php endif; ?>
              </div>
              <div class="col-6">
                <?php if(empty($hoso)): ?>
               <!--  <a href="" class="btn btn-block btn-primary btn-md">Ứng tuyển</a>       -->          
                <a href="<?php echo e(url('/nguoitimviec/choose-apply',$news->id)); ?>" class="btn btn-block btn-primary btn-md">Ứng tuyển</a> 
                <?php else: ?>                
                <a href="javascript:void(0)" class="btn btn-block btn-danger btn-md">Đã nộp đơn vào </br>
                  <?php echo e(date("d-m-Y", strtotime($hoso->created_at))); ?>

                </a>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-8">
            <div class="mb-5">
              <figure class="mb-5"><img src="<?php echo e(url('images/job_single_img_1.jpg')); ?>" alt="Image" class="img-fluid rounded"></figure>
              <h3 class="h5 d-flex align-items-center mb-4 text-primary"><span class="icon-align-left mr-3"></span>Mô tả công việc</h3>
               <ul class="list-unstyled m-0 p-0">
              <?php if($news->motacv): ?>
                <?php $__currentLoopData = json_decode($news->motacv); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chitiet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span><?php echo $chitiet; ?></span></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
              <?php endif; ?>                
              </ul>              
            </div>
            <div class="mb-5">
              <h3 class="h5 d-flex align-items-center mb-4 text-primary"><span class="icon-rocket mr-3"></span>Quyền lợi</h3>
              <ul class="list-unstyled m-0 p-0">
              <?php if($news->quyenloi): ?>
                <?php $__currentLoopData = json_decode($news->quyenloi); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quyenloi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span><?php echo $quyenloi; ?></span></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>               
              </ul>
            </div>

            <div class="mb-5">
              <h3 class="h5 d-flex align-items-center mb-4 text-primary"><span class="icon-book mr-3"></span>Thông tin liên hệ</h3>
              <ul class="list-unstyled m-0 p-0">
              <?php if($news->ttlienhe): ?>
                <?php $__currentLoopData = json_decode($news->ttlienhe); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chitiet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="d-flex align-items-start mb-2"><span class="icon-check_circle mr-2 text-muted"></span><span><?php echo $chitiet; ?></span></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>               
              </ul>
            </div> 
            <?php if($news->yeucau_cv): ?>
            <div class="mb-5">
              <h3 class="h5 d-flex align-items-center mb-4 text-primary"><span class="icon-asterisk mr-3"></span>Yêu cầu thêm</h3>
              <ul class="list-unstyled m-0 p-0">
              <?php echo nl2br($news->yeucau_cv); ?>             
              </ul>
            </div>          
            <?php endif; ?>
            <div class="row mb-5">
              <?php if(Auth::check()): ?>
                <?php if(!empty(Auth::user()->theodoi)): ?>
                  <?php if(in_array($news->id,json_decode(Auth::user()->theodoi))): ?>
                  <div class="col-6 follow">                
                    <a href="javascript:void(0)" id="<?php echo e($news->id); ?>" class="btn btn-block btn-dark btn-md"><span class="icon-heart mr-2 text-danger"></span>Đang theo dõi</a>
                  </div>   
                  <?php else: ?>
                  <div class="col-6 follow">                
                    <a href="javascript:void(0)" id="<?php echo e($news->id); ?>" class="btn btn-block btn-light btn-md follow-news"><span class="icon-heart-o mr-2 text-danger"></span>Theo dõi tin tuyển dụng</a>                
                  </div>             
                  <?php endif; ?>
                <?php else: ?>
                <div class="col-6 follow">                
                  <a href="javascript:void(0)" id="<?php echo e($news->id); ?>" class="btn btn-block btn-light btn-md follow-news"><span class="icon-heart-o mr-2 text-danger"></span>Theo dõi tin tuyển dụng</a>                
                </div>
                <?php endif; ?>
              <?php endif; ?>
              <div class="col-6">
                <?php if(empty($hoso)): ?>
                <a href="<?php echo e(route('apply',$news->id)); ?>" class="btn btn-block btn-primary btn-md">Ứng tuyển</a>
                <?php else: ?>
                <a href="javascript:void(0)" class="btn btn-block btn-danger btn-md">Đã nộp đơn vào <?php echo e(date('d-m-Y',strtotime($hoso->created_at))); ?></a>
                <?php endif; ?>
              </div>
            </div>

          </div>
          <div class="col-lg-4">
            <div class="bg-light p-3 border rounded mb-4">
             
              <h3 class="text-primary  mt-3 h5 pl-3 mb-3 ">Tổng quan</h3>
              <ul class="list-unstyled pl-3 mb-0">
                <li class="mb-2"><strong class="text-black">Ngày đăng:</strong> <?php echo e(date("d-m-Y", strtotime($news->created_at))); ?></li>
                <li class="mb-2"><strong class="text-black">Vị trí cần tuyển: <span class="badge badge-primary"><?php echo e($news->capbac); ?></span></strong></li>
                <li class="mb-2"><strong class="text-black">Số lượng:</strong> <?php echo e($news->soluong); ?> người</li>                               
                <li class="mb-2"><strong class="text-black">Hình thức làm việc:</strong> <?php echo e($news->hinhthuc_lv); ?></li>                
                <li class="mb-2"><strong class="text-black">Khu vực làm việc:</strong> 
                  <?php $__currentLoopData = json_decode($news->tinhthanhpho); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="badge badge-dark"><?php echo e($tp); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
                <li class="mb-2"><strong class="text-black">Mức lương:</strong> <?php echo $news->mucluong; ?></li>                
                <li class="mb-2"><strong class="text-black">Hạn tuyển dụng: </strong><span class="text-danger"><?php echo e(date("d-m-Y", strtotime($news->hantuyendung))); ?></span></li>
                <li class="mb-2"><strong class="text-black">Thời gian thử việc: </strong><span class="text-info"><?php echo e($news->tg_thuviec); ?></span></li>
                <?php if($news->website): ?>
                <li class="mb-2"><strong class="text-black">Website:</strong> <?php echo e($news->website); ?></li>
                <?php endif; ?>
                <li class="mb-2"><strong class="text-black">Lượt xem: </strong><span class="text-danger"><?php echo e($news->luotxem); ?></span></li>
              </ul>
            </div>

            <div class="bg-light p-3 border rounded">
              <h3 class="text-primary  mt-3 h5 pl-3 mb-3 ">Yêu cầu</h3>
              <ul class="list-unstyled pl-3 mb-0">
                <li class="mb-2"><strong class="text-black">Giới tính:</strong> <?php echo e($news->gioitinh); ?></li>
                <li class="mb-2">
                  <strong class="text-black">Kĩ năng: </strong>
                  <?php $__currentLoopData = json_decode($news->kinang); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="badge badge-info"><?php echo e($skill); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
                <li class="mb-2">
                  <strong class="text-black">Trình độ: </strong>
                  <?php echo e($news->bangcap); ?>

                </li>
                <li class="mb-2">
                  <strong class="text-black">Kinh nghiệm: </strong>
                  <?php echo e($news->kinhnghiem); ?>

                </li>
                <?php if($news->ngoaingu): ?>
                <li class="mb-2"><strong class="text-black">Ngoại ngữ:</strong>                 
                <?php $__currentLoopData = json_decode($news->ngoaingu); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="badge badge-secondary"><?php echo e($language); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
                <?php endif; ?>
                
                <?php if($news->tinhoc): ?>
                <li class="mb-2"><strong class="text-black">Trình độ tin học:</strong>                 
                <?php $__currentLoopData = json_decode($news->tinhoc); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="badge badge-primary"><?php echo e($itech); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
                <?php endif; ?>

              </ul>               
            </div>

          </div>
        </div>
      </div>
    </section>

    <section class="site-section" id="next">
      <div class="container">
        <div class="row mb-5 justify-content-center">
          <div class="col-md-7 text-center">
            <h2 class="section-title mb-2"><?php echo e($related_jobs->count()); ?> tin tuyển dụng liên quan</h2>
          </div>
        </div>
        
        <ul class="job-listings mb-5">
          <?php $__currentLoopData = $related_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="job-listing d-block d-sm-flex pb-3 pb-sm-0 align-items-center">
            <a href="<?php echo e(route('news',$job->id)); ?>"></a>
            <div class="job-listing-logo">
              <?php if($job->hinh): ?>
              <img src="<?php echo e(url('logo/'.$job->hinh)); ?>" alt="<?php echo e($job->hinh); ?>" style="width: 200px; height: 150px">
              <?php else: ?>
              <img src="<?php echo e(url('logo/default.png')); ?>" alt="Không có hình" class="img-fluid">
              <?php endif; ?>
            </div>

            <div class="job-listing-about d-sm-flex custom-width w-100 justify-content-between mx-4">
              <div class="job-listing-position custom-width w-50 mb-3 mb-sm-0">
                <h2><?php echo e($job->nganh); ?></h2>
                <strong>Nhà tuyển dụng <?php echo e($job->ten); ?></strong>
                <div class="keywords">
                  <?php $__currentLoopData = json_decode($job->kinang); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <button class="btn btn-outline-info skill"><?php echo e($skill); ?></button>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                </div>      
              </div>
              <div class="job-listing-location mb-3 mb-sm-0 custom-width w-25">  
                <?php $__currentLoopData = json_decode($job->tinhthanhpho); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="icon-room"></span><?php echo e($city); ?></br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="job-listing-meta">
                <?php if($job->hinhthuc_lv == 'Part Time'): ?>
                <span class="badge badge-danger"><?php echo e($job->hinhthuc_lv); ?></span>
                <?php else: ?>
                <span class="badge badge-success"><?php echo e($job->hinhthuc_lv); ?></span>
                <?php endif; ?>
              </br>
                <span class="badge badge-dark">Giờ đăng: <?php echo e(time_elapsed_string($job->created_at)); ?></span>
              </br>
              <span class="badge badge-info">Hạn tuyển dụng: <?php echo e(date("d-m-Y", strtotime($job->hantuyendung))); ?></span>
              </div>              
            </div>            
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
        </ul>
      </div>
    </section>
    

    <section class="bg-light pt-5 testimony-full">
        <div class="owl-carousel single-carousel">
          <div class="container">
            <div class="row">
              <div class="col-lg-6 align-self-center text-center text-lg-left">
                <blockquote>
                  <p>&ldquo;Hãy đăng ký để trở thành hội viên của Website để sử dụng những dịch vụ tiện ích nhất&rdquo;</p>
                  <p><cite> &mdash; Hồng Phát, @HTP</cite></p>
                </blockquote>
              </div>
              <div class="col-lg-6 align-self-end text-center text-lg-right">
                <img src="<?php echo e(asset('images/person_transparent_2.png')); ?>" alt="Image" class="img-fluid mb-0">
              </div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-6 align-self-center text-center text-lg-left">
                <blockquote>
                  <p>&ldquo;Tìm việc phù hợp & tuyển dụng nhân lực nhanh chóng.&rdquo;</p>
                  <p><cite> &mdash; Hồng Phát, @HTP</cite></p>
                </blockquote>
              </div>
              <div class="col-lg-6 align-self-end text-center text-lg-right">
                <img src="<?php echo e(asset('images/person_transparent.png')); ?>" alt="Image" class="img-fluid mb-0">
              </div>
            </div>
          </div>
      </div>
    </section>

    <section class="pt-5 bg-image overlay-primary fixed overlay" style="background-image: url('images/hero_1.jpg');">
      <div class="container">
        <div class="row">
          <div class="col-md-6 align-self-center text-center text-md-left mb-5 mb-md-0">
            <h2 class="text-white">Mobile</h2>
            <p class="mb-5 lead text-white">Giao diện tương thích, tiện ích và dễ sử dụng.</p>
            <p class="mb-0">
              <a href="javascript:void(0)" class="btn btn-dark btn-md px-4 border-width-2"><span class="icon-apple mr-3"></span>IOS</a>
              <a href="javascript:void(0)" class="btn btn-dark btn-md px-4 border-width-2"><span class="icon-android mr-3"></span>Android</a>
            </p>
          </div>
          <div class="col-md-6 ml-auto align-self-end">
            <img src="<?php echo e(asset('images/apps.png')); ?>" alt="Free Website Template by Free-Template.co" class="img-fluid">
          </div>
        </div>
      </div>
    </section>

    <!-- Ajax -->
    <script src="<?php echo e(url('ajax/save-job.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>