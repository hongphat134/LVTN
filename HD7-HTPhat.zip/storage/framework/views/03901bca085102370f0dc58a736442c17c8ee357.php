<pre>
chúng tôi đại diện cho nhà tuyển dụng <?php echo e($recruiter->ten); ?> gửi thông báo đến bạn! </br>
<?php if($status == 1): ?> 
Bạn đã trúng ứng tuyển! Hãy vào <?php echo e(config('app.url')); ?> để xem thêm chi tiết!
<?php else: ?> Rất tiếc, nhà tuyển dụng đã từ chối yêu cầu ứng tuyển! Bạn đừng buồn nhé! Hãy tìm kiếm công việc khác tại <?php echo e(config('app.url')); ?>! Chúc bạn may mắn!
<?php endif; ?>
</br>
<label for="content">Nội dung:</label>
<?php echo e($content); ?>


</br>
Thông tin nhà tuyển dụng:
Địa chỉ: <?php echo e($recruiter->diachi); ?>, <?php echo e($recruiter->tinhthanhpho); ?>

Email liên hệ: <?php echo e($recruiter->email); ?>

SDT liên hệ: <?php echo e($recruiter->sdt); ?>

</pre>