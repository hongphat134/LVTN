<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Thông tin hồ sơ</h1>
            <div class="custom-breadcrumbs">
              <a href="#">Home</a> <span class="mx-2 slash">/</span>
              <a href="#">Job</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Thông tin hồ sơ</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    
    <section class="site-section">
      <div class="container">

        <div class="row align-items-center mb-5">
          <div class="col-lg-8 mb-4 mb-lg-0">
            <div class="d-flex align-items-center">
              <div>
                <h2>Thông tin hồ sơ</h2>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="row">              
              <div class="col-12">
                <a href="#" class="btn btn-block btn-primary btn-md"
                    onclick="event.preventDefault();
                           document.getElementById('profile').submit();">
                <span class="icon-users mr-2"></span>Cập nhật thông tin
              </a>
              </div>
            </div>
          </div>
        </div>
        <div class="row mb-5">
          <div class="col-lg-12">
            <form id="profile" action="<?php echo e(url('/nhatuyendung/profile')); ?>" class="p-4 p-md-5 border rounded" method="post" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <h3 class="text-black mb-5 border-bottom pb-2">Thông tin hồ sơ</h3>
              <?php if(session('success')): ?>
              <div class="alert alert-success alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <?php echo e(session('success')); ?>

              </div>
              <?php endif; ?>  
              <div class="form-group">
                <label for="company-website-tw d-block col-lg-2">Upload logo</label> <br>
                <label class="btn btn-primary btn-md btn-file col-lg-2">
                  Browse File<input type="file" name="logo" hidden>
                </label>
                <?php if($profile->hinh): ?>
                <label class="col-lg-2 d-inline-flex">Logo hiện tại</label>
                <div class="col-lg-6 d-inline-flex">
                  <img src="<?php echo e(asset('/logo/'.$profile->hinh)); ?>" alt="<?php echo e($profile->hinh); ?>" style="width: 200px; height: 200px">
                </div>
                <?php endif; ?>
              </div>

              <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                <label for="email">Tên nhà tuyển dụng</label>
                <input type="text" name="name" class="form-control" placeholder="Nhập tên...." value="<?php echo e($profile->ten); ?>">
                <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
              </div> 
              
              <div class="form-group<?php echo e($errors->has('contact_name') ? ' has-error' : ''); ?>">
                <label for="email">Tên người liên hệ</label>
                <input type="text" name="contact_name" class="form-control"  placeholder="Nhập Họ tên...." value="<?php echo e(empty($profile->tenlh)? old('contact_name'): $profile->tenlh); ?>">
                <?php if($errors->has('contact_name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('contact_name')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>

              <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                <label for="email">SDT liên hệ</label>
                <input type="text" name="phone" class="form-control"  placeholder="Nhập SDT...." value="<?php echo e(empty($profile->sdt)? old('phone'): $profile->sdt); ?>" required>
                <?php if($errors->has('phone')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('phone')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>

              <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <label for="email">Email liên hệ</label>
                <input type="email" name="email" class="form-control" placeholder="Nhập Email liên hệ...." value="<?php echo e(empty($profile->email)? old('email'): $profile->email); ?>">
                <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>

              <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                <label for="email">Địa chỉ</label>
                <input type="text" name="address" class="form-control" placeholder="Nhập địa chỉ...." value="<?php echo e($profile->diachi); ?>">
                <?php if($errors->has('address')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('address')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>         

              <div class="form-group">
                <label for="job-region">khu vực hoạt động</label>
                <select class="selectpicker border rounded" name="region" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn khu vự...">                     
                      <?php $__currentLoopData = $region_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region => $city_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                      <optgroup label="<?php echo e($region == 'MienNam' ? 'Miền Nam' : ($region == 'MienBac' ? 'Miền Bắc' : 'Miền Trung')); ?>">
                        <?php $__currentLoopData = $city_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($profile->tinhthanhpho == $city->Ten ? 'selected':''); ?>><?php echo e($city->Ten); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </optgroup>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>               
              </div>

              <div class="form-group">
                <label for="job-region">Quy mô dân sự</label>
                <select class="selectpicker border rounded" name="scale" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn quy mô...">
                      <?php $__currentLoopData = $scale_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                     
                      <option <?php echo e($profile->quymodansu == $scale ? 'selected':''); ?>><?php echo e($scale); ?></option>                  
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>              
              </div>

              <div class="form-group">
                <label for="company-website">Văn hoá & phúc lợi</label>
                <textarea class="form-control" name="culture" id="" cols="30" rows="10" placeholder="Nhập văn hoá, phúc lợi..."><?php echo e($profile->vanhoaphucloi); ?></textarea>
              </div>

              <div class="form-group<?php echo e(session('error') ? ' has-error' : ''); ?>">
                <label for="company-website">Website công ty</label>
                <input type="text" name="website" class="form-control" id="company-website" placeholder="https://" value="<?php echo e(empty($profile->website)? old('website'): $profile->website); ?>">
                <?php if(session('error')): ?>
                    <span class="help-block">
                        <strong><?php echo e(session('error')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
        <div class="row align-items-center mb-5">
          
          <div class="col-lg-4 ml-auto">
            <div class="row">              
              <div class="col-12">
                <a href="#" class="btn btn-block btn-primary btn-md"
                      onclick="event.preventDefault();
                           document.getElementById('profile').submit();"
                >
                <span class="icon-users mr-2"></span>Cập nhật thông tin
            </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>