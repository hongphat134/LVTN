<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Diễn đàn</h1>
            <div class="custom-breadcrumbs">
              <a href="<?php echo e(url('/')); ?>">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Diễn đàn</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section" id="content">
      <div class="container">
        <div class="row mb-5 justify-content-center">
          <div class="col-md-7 text-center">
            <h1 class="section-title mb-2">
              <span class="icon-forumbee mr-2"></span>Diễn đàn <span class="icon-forumbee"></span>
            </h1>
          </div>
        </div>  
        

        <div class="row mb-5">
          <?php $__currentLoopData = $blog_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6 col-lg-4 mb-5">
            <a href="<?php echo e(url('blog-single',$blog->id)); ?>"><img src="<?php echo e(asset('blog_images/'.$blog->hinh)); ?>" alt="Image" class="img-fluid rounded mb-4"></a>
            <h3><a href="<?php echo e(url('blog-single',$blog->id)); ?>" class="text-black"><?php echo e($blog->tieude); ?></a></h3>
            <div>Ngày đăng: <?php echo e(date('d/m/Y',strtotime($blog->updated_at))); ?> <span class="mx-2">|</span> <a href="#"><?php echo e($blog->count); ?> bình luận</a></div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

      </div>
      <?php echo $__env->make('layouts.paginating',['job_listings' => $blog_list], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>