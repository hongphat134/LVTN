<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image home-section" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Cập nhật tin tuyển dụng</h1>
            <div class="custom-breadcrumbs">
              <a href="#">Home</a> <span class="mx-2 slash">/</span>
              <a href="#">Job</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Cập nhật tin tuyển dụng</strong></span>
            </div>
          </div>
        </div>
      </div>
      <a href="#footer" class="scroll-button smoothscroll">
        <span class=" icon-keyboard_arrow_down"></span>
      </a>
    </section>

    
    <section class="site-section">
      <div class="container">

        <div class="row align-items-center mb-5">
          <div class="col-lg-8 mb-4 mb-lg-0">
            <div class="d-flex align-items-center">
              <div>
                <h2>Cập nhật tin tuyển dụng</h2>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="row">
              <div class="col-6">
                <a href="#" class="btn btn-block btn-light btn-md preview" data-toggle="modal" data-target=".bd-example-modal-xl">
                  <span class="icon-open_in_new mr-2"></span>Xem trước</a>
                </div>
                <div class="col-6">
                  <a href="#" class="btn btn-block btn-primary btn-md"
                          onclick="event.preventDefault();
                             document.getElementById('post-job').submit();">
                  <span class="icon-edit mr-2"></span>Cập nhật tin
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="row mb-5">
          <div class="col-lg-12">
            <form id="post-job" action="<?php echo e(route('updateJob',$news->id)); ?>" class="p-4 p-md-5 border rounded" method="post">
              <?php echo e(csrf_field()); ?>

              <h3 class="text-black mb-5 border-bottom pb-2">Thông tin tuyển dụng</h3>
              <?php if(session('success')): ?>
              <div class="alert alert-success alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <?php echo e(session('success')); ?>

              </div>
              <?php endif; ?>            

              <div class="row form-group">
                <label for="job" class="col-lg-2 col-sm-12 col-form-label">Hạn tuyển dụng 
                <sup><span class="text-danger"><i class="icon-asterisk"></i></span></sup>
                </label>              
                <div class="col-lg-2 col-sm-12<?php echo e($errors->has('deadline') || session('errorDate') ? ' has-error' : ''); ?>">
                  <input type="date" class="form-control" name="deadline" value="<?php echo e($news->hantuyendung); ?>">
                  <?php if($errors->has('deadline')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('deadline')); ?></strong>
                      </span>                
                  <?php elseif(session('errorDate')): ?>
                      <span class="help-block">
                          <strong><?php echo e(session('errorDate')); ?></strong>
                      </span>
                  <?php endif; ?> 
                </div>  

                <label for="job" class="col-lg-2 col-sm-12 col-form-label">Số lượng
                <sup><span class="text-danger"><i class="icon-asterisk"></i></span></sup>
                </label>              
                <div class="col-lg-2 col-sm-12<?php echo e($errors->has('vacancy')? ' has-error' : ''); ?>">                  
                  <input type="number" class="form-control" id="job-title" name="vacancy" min="1" max="99" placeholder="Nhập số lượng...." value="<?php echo e($news->soluong); ?>">
                  <?php if($errors->has('vacancy')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('vacancy')); ?></strong>
                      </span>
                  <?php endif; ?>
                </div>

                <label for="job" class="col-lg-2 col-sm-12 col-form-label">Giới tính 
                <sup><span class="text-danger"><i class="icon-asterisk"></i></span></sup>
                </label>              
                <div class="col-lg-2 col-sm-12">
                  <select class="selectpicker border rounded" data-style="btn-black" data-width="100%" data-live-search="true" name="gender">
                    <option selected>Không yêu cầu</option>
                    <option <?php echo e($news->gioitinh == 'Nam' ? 'selected':''); ?>>Nam</option>
                    <option <?php echo e($news->gioitinh == 'Nữ' ? 'selected':''); ?>>Nữ</option>
                  </select> 
                </div> 
              </div>       

              <div class="row form-group">
                <label for="job" class="col-lg-2 col-sm-12 col-form-label">Ngành nghề
                  <sup><span class="text-danger"><i class="icon-asterisk"></i></span></sup>
                </label>              
                <div class="col-lg-4 col-sm-12<?php echo e($errors->has('job')? ' has-error' : ''); ?>">
                  <select class="selectpicker border" name="job" id="title" data-style="btn-white" data-width="100%" data-live-search="true" data-size="8" title="Chọn ngành nghề" required>
                    <?php if(in_array($news->nganh,$job_list)): ?>                                  
                      <?php $__currentLoopData = $job_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                      <option <?php echo e(strcasecmp($news->nganh,$job) == 0?'selected':''); ?>><?php echo e($job); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <option value="other">Khác</option>
                    <?php else: ?>                                          
                      <?php $__currentLoopData = $job_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                      <option><?php echo e($job); ?></option>                      
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                      <option value="other" selected="true">Khác</option>
                    <?php endif; ?>
                  </select> 
                  <?php if($errors->has('job')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('job')); ?></strong>
                        </span>
                  <?php endif; ?> 
                </div>  

                <div id="other_title" class="col-lg-6 col-sm-12" 
                <?php if(in_array($news->nganh,$job_list) && !session('errorJob')): ?> style="display: none;"
                <?php endif; ?>>
                  <div class="row">
                    <label for="job" class="col-lg-4 col-sm-12 col-form-label">Ngành nghề khác
                     <sup><span class="text-danger"><i class="icon-asterisk"></i></span></sup>
                    </label>              
                    <div class="col-lg-8 col-sm-12<?php echo e(session('errorJob')? ' has-error' : ''); ?>">                  
                      <input type="text" name="other_title" class="form-control" placeholder="Nhập tên ngành nghề..." value="<?php echo e(in_array($news->nganh,$job_list) ? '' : $news->nganh); ?>" required>
                      <?php if(session('errorJob')): ?>
                        <span class="help-block">
                            <strong><?php echo e(session('errorJob')); ?></strong>
                        </span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </div>    

              <div class="row form-group">
                <label for="job" class="col-lg-2 col-sm-12 col-form-label">Kĩ năng cần thiết 
                  <sup><span class="text-danger"><i class="icon-asterisk"></i></span></sup>
                </label>              
                <div class="col-lg-4 col-sm-12<?php echo e($errors->has('skill')? ' has-error' : ''); ?>">
                  <select class="selectpicker border rounded" id="skill-list" data-style="btn-black" data-width="100%" data-size="10" data-live-search="true" name="skill[]" title="Chọn kĩ năng (tối đa 5)" multiple data-max-options="5">
                  <?php if(empty($news->kinang)): ?>                    
                    <?php $__currentLoopData = $skill_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($skill); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>                  
                    <?php $__currentLoopData = $skill_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(in_array($skill,$news->kinang) ? 'selected' : ''); ?>><?php echo e($skill); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                  </select>
                  <?php if($errors->has('skill')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('skill')); ?></strong>
                      </span>
                  <?php endif; ?> 
                </div>                             

                <label for="job" class="col-lg-2 col-sm-12 col-form-label">Vị trí tuyển dụng
                <sup><span class="text-danger"><i class="icon-asterisk"></i></span></sup>
                </label>              
                <div class="col-lg-4 col-sm-12<?php echo e($errors->has('rank')? ' has-error' : ''); ?>">                  
                  <select class="selectpicker border rounded" data-style="btn-black" data-width="100%" data-live-search="true" name="rank" title="Chọn vị trí...">
                  <?php $__currentLoopData = $rank_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                    <option <?php echo e($rank == $news->capbac ?'selected':''); ?>><?php echo e($rank); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php if($errors->has('rank')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('rank')); ?></strong>
                      </span>
                  <?php endif; ?>
                </div>
              </div>

              <div class="row form-group">
                <label for="job" class="col-lg-3 col-sm-12 col-form-label">Yêu cầu kinh nghiệm 
                <sup><span class="text-danger"><i class="icon-asterisk"></i></span></sup>
                </label>              
                <div class="col-lg-3 col-sm-12<?php echo e($errors->has('exp')? ' has-error' : ''); ?>">
                  <select class="selectpicker border rounded" id="job-type" data-style="btn-black" data-width="100%" data-live-search="true" name="exp" title="Chọn yêu cầu...">
                  <?php $__currentLoopData = $exp_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                    <option <?php echo e($exp == $news->kinhnghiem ?'selected':''); ?>><?php echo e($exp); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php if($errors->has('exp')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('exp')); ?></strong>
                      </span>
                  <?php endif; ?>
                </div>  

                <label for="job" class="col-lg-2 col-sm-12 col-form-label">Mức lương
                <sup><span class="text-danger"><i class="icon-asterisk"></i></span></sup>
                </label>              
                <div class="col-lg-4 col-sm-12<?php echo e($errors->has('salary')? ' has-error' : ''); ?>">                  
                  <select class="selectpicker border rounded" data-style="btn-black" data-width="100%" data-live-search="true" name="salary" title="Chọn mức lương...">
                  <?php $__currentLoopData = $salary_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                    <option <?php echo e($salary == $news->mucluong ?'selected':''); ?>><?php echo e($salary); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php if($errors->has('salary')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('salary')); ?></strong>
                      </span>
                  <?php endif; ?>
                </div>
              </div>

              <div class="row form-group">
                <label for="job" class="col-lg-3 col-sm-12 col-form-label">Yêu cầu trình độ 
                <sup><span class="text-danger"><i class="icon-asterisk"></i></span></sup>
                </label>              
                <div class="col-lg-3 col-sm-12<?php echo e($errors->has('degree')? ' has-error' : ''); ?>">
                  <select class="selectpicker border rounded" data-style="btn-black" data-width="100%" data-live-search="true" name="degree" title="Chọn yêu cầu...">
                <?php $__currentLoopData = $degree_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                  <option <?php echo e($degree == $news->bangcap ?'selected':''); ?>><?php echo e($degree); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('degree')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('degree')); ?></strong>
                    </span>
                <?php endif; ?> 
                </div>  

                <label for="job" class="col-lg-3 col-sm-12 col-form-label">Hình thức làm việc
                <sup><span class="text-danger"><i class="icon-asterisk"></i></span></sup>
                </label>              
                <div class="col-lg-3 col-sm-12<?php echo e($errors->has('status')? ' has-error' : ''); ?>">                  
                  <select class="selectpicker border rounded" data-style="btn-black" data-width="100%" data-live-search="true" name="status">                    
                    <option selected>Full Time</option>
                    <option <?php echo e($news->trangthailv == 'Part Time' ? 'selected':''); ?>>Part Time</option>
                </select>
                </div>
              </div>         
              
              <div class="row form-group">
                <label for="job" class="col-lg-2 col-sm-12 col-form-label">Nơi làm việc
                <sup><span class="text-danger"><i class="icon-asterisk"></i></span></sup>
                </label>               
                <div class="col-lg-4 col-sm-12<?php echo e($errors->has('region')? ' has-error' : ''); ?>">
                  <select class="selectpicker border rounded" id="region-list" data-style="btn-black" data-width="100%" data-live-search="true" name="region[]" title="Chọn khu vực (tối đa 3)" data-size="10" multiple data-max-options="3">                     
                  <?php $__currentLoopData = $region_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region => $city_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                  <optgroup label="<?php echo e($region == 'MienNam' ? 'Miền Nam' : ($region == 'MienBac' ? 'Miền Bắc' : 'Miền Trung')); ?>">
                    <?php $__currentLoopData = $city_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option                   
                      <?php echo e(in_array($city->Ten,json_decode($news->tinhthanhpho)) ? 'selected=true': ''); ?>>
                    <?php echo e($city->Ten); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </optgroup>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>

                  <?php if($errors->has('region')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('region')); ?></strong>
                    </span>
                  <?php endif; ?>  
                </div>  

                <label for="job" class="col-lg-2 col-sm-12 col-form-label">Thời gian thử việc
                <sup><span class="text-danger"><i class="icon-asterisk"></i></span></sup>
                </label>              
                <div class="col-lg-4 col-sm-12<?php echo e($errors->has('probation')? ' has-error' : ''); ?>">                  
                  <select class="selectpicker border rounded" data-style="btn-black" data-width="100%" data-live-search="true" name="probation">
                    <option selected>Nhận việc ngay</option>                  
                    <option <?php echo e($news->tg_thuviec == '1 tháng' ? 'selected' : ''); ?>>1 tháng</option>
                    <option <?php echo e($news->tg_thuviec == '2 tháng' ? 'selected' : ''); ?>>2 tháng</option>
                    <option <?php echo e($news->tg_thuviec == '3 tháng' ? 'selected' : ''); ?>>3 tháng</option>
                    <option <?php echo e($news->tg_thuviec == 'Trao đổi trực tiếp khi phỏng vấn' ? 'selected' : ''); ?>>Trao đổi trực tiếp khi phỏng vấn</option>
                </select>
                </div>
              </div> 
              
              <?php 
                $other_languages = '';
                if($news->ngoaingu)
                foreach(json_decode($news->ngoaingu) as $language) {
                  if(!in_array($language, $language_list)) $other_languages .= $language.',';
                }
              ?>
              <h3 class="text-black my-5 border-bottom pb-2">Yêu cầu trình độ ngoại ngữ</h3>
              <div class="row form-group">              
                <label for="language" class="col-lg-2 col-sm-12 col-form-label">Ngoại ngữ &nbsp;
                  <span class="text-primary"><i class="icon-language"></i></span>
                </label>              
                <div class="col-lg-4 col-sm-12">
                  <select class="selectpicker border rounded" data-style="btn-black" data-width="100%" data-live-search="true" name="language[]" id="language" title="Chọn ngoại ngữ..." multiple>
                    <?php if($news->ngoaingu): ?>
                      <?php $__currentLoopData = $language_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option 
                      <?php echo e(in_array($language, json_decode($news->ngoaingu) ) ? 'selected' : ''); ?>>
                      <?php echo e($language); ?>

                      </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                      <?php $__currentLoopData = $language_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option><?php echo e($language); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>   
                    <option value="other"<?php echo e($other_languages ? 'selected' : ''); ?>>Ngôn ngữ khác
                      </option>             
                  </select>                
                </div>  

                <div id="other_language" class="col-lg-6 col-sm-12" 
                <?php if(!$other_languages): ?> style="display: none;"
                <?php endif; ?>>
                  <div class="row">
                    <label for="job" class="col-lg-4 col-sm-12 col-form-label">Ngoại ngữ khác &nbsp;
                     <sup><span class="text-primary"><i class="icon-language"></i></span></sup>
                    </label>              
                    <div class="col-lg-8 col-sm-12">                  
                      <input type="text" name="other_language" class="form-control" placeholder="Nếu nhập nhiều, hãy nhập (VD: Anh,Pháp,Đức,...)" value="<?php echo e($other_languages ? substr($other_languages, 0, -1) : ''); ?>" required>
                    </div>
                  </div>
                </div>
              </div>

              <?php 
                $other_itechs = '';
                if($news->tinhoc)
                foreach(json_decode($news->tinhoc) as $itech) {
                  if(!in_array($itech, $itech_list)) $other_itechs .= $itech.',';
                }
              ?>
              <h3 class="text-black my-5 border-bottom pb-2">Yêu cầu trình độ tin học</h3>
                <div class="row form-group">              
                  <label for="itech" class="col-lg-2 col-sm-12 col-form-label">Phần mềm &nbsp;
                    <span class="text-primary"><i class="icon-gear"></i></span>
                  </label>              
                  <div class="col-lg-4 col-sm-12">
                     <select class="selectpicker border rounded" name="itech[]" id="itech" data-style="btn-black" data-width="100%" data-live-search="true" title="Chọn phần mềm" multiple>
                       <?php if($news->tinhoc): ?>
                        <?php $__currentLoopData = $itech_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e(in_array($itech, json_decode($news->tinhoc) ) ? 'selected' : ''); ?>>
                        <?php echo e($itech); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <?php $__currentLoopData = $itech_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option><?php echo e($itech); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>         
                      <option value="other" <?php echo e($other_itechs ? 'selected' : ''); ?>>Phần mềm khác</option>
                    </select>  
                  </div>                

                <div id="other_itech" class="col-lg-6 col-sm-12" 
                <?php if(!$other_itechs): ?> style="display: none;"
                <?php endif; ?>>
                  <div class="row">
                    <label for="job" class="col-lg-4 col-sm-12 col-form-label">Phần mềm khác &nbsp;
                     <sup><span class="text-primary"><i class="icon-hand-o-right"></i></span></sup>
                    </label>              
                    <div class="col-lg-8 col-sm-12">                  
                      <input type="text" name="other_itech" class="form-control" id="name" placeholder="Nhập tên phần mềm...(Access,Visio,Github,...)" value="<?php echo e($other_itechs ? substr($other_itechs, 0, -1) : ''); ?>" required>
                    </div>
                  </div>
                </div>
              </div>
          
              <h3 class="text-black my-5 border-bottom pb-2">Mô tả công việc</h3>
              <div class="form-group">
              <?php if($news->motacv): ?>
                <?php $__currentLoopData = json_decode($news->motacv); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $des): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" name="des_job[]" class="form-control" placeholder="Nội dung..." value="<?php echo e($des); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
              <?php endif; ?>
                <input type="text" name="des_job[]" class="form-control" placeholder="Nội dung...">                
                <button type="button" id="des-job" class=" btn btn-secondary form-control">Thêm <span class="icon-plus"></span>
                </button>
              </div>

              <h3 class="text-black my-5 border-bottom pb-2">Quyền lợi</h3>
              <div class="form-group">
              <?php if($news->quyenloi): ?>
                <?php $__currentLoopData = json_decode($news->quyenloi); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benefit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" name="benefit[]" class="form-control" placeholder="Nội dung..." value="<?php echo e($benefit); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                             
              <?php endif; ?>
                <input type="text" name="benefit[]" class="form-control" id="company-name" placeholder="Nội dung...">
                <button type="button" id="benefit" class="btn btn-dark btn-block">
                Thêm <span class="icon-plus"></span></button>               
              </div>

              <h3 class="text-black my-5 border-bottom pb-2">Thông tin liên hệ</h3>
              <div class="form-group">
              <?php if($news->ttlienhe): ?>
                <?php $__currentLoopData = json_decode($news->ttlienhe); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" name="info_contact[]" class="form-control" id="company-name" placeholder="Thông tin..." value="<?php echo e($info); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
              <?php endif; ?>
                <input type="text" name="info_contact[]" class="form-control" id="company-name" placeholder="Thông tin...">
                <button type="button" id="info-contact" class="btn btn-primary form-control">Thêm <span class="icon-plus"></span></button>
              </div>

               <h3 class="text-black my-5 border-bottom pb-2">Thông tin thêm</h3>
              <div class="form-group">
                <textarea class="form-control" name="plus" cols="30" rows="3" placeholder="Nhập yêu cầu...."><?php echo e($news->yeucau_cv); ?></textarea>
              </div>
            </form>
          </div>

         
        </div>
        <div class="row align-items-center mb-5">
          
          <div class="col-lg-4 ml-auto">
            <div class="row">
              <div class="col-6">
                <a href="#" class="btn btn-block btn-light btn-md preview" data-toggle="modal" data-target=".bd-example-modal-xl"><span class="icon-open_in_new mr-2"></span>Xem trước</a>
              </div>
              <div class="col-6">
                <a href="#" class="btn btn-block btn-primary btn-md"
                        onclick="event.preventDefault();
                           document.getElementById('post-job').submit();">                  
                  <span class="icon-edit mr-2"></span>Cập nhật tin
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

<div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true" style="z-index: 1999">
  <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalScrollableTitle">Xem trước</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">            
    <section class="site-section" style="padding-top:0">
      <div class="container">
        <div class="row">
          <div class="col-lg-7">
            <div class="mb-5">
              <figure class="mb-5"><img src="<?php echo e(asset('images/job_single_img_1.jpg')); ?>" alt="Image" class="img-fluid rounded"></figure>
              <h3 class="h5 d-flex align-items-center mb-4 text-info"><span class="icon-align-left mr-3"></span>Mô tả công việc</h3>
              <span id="des-preview">              
              </span>
            </div>
            <div class="mb-5">
              <h3 class="h5 d-flex align-items-center mb-4 text-info"><span class="icon-rocket mr-3"></span>Quyền lợi</h3>
              <ul class="list-unstyled m-0 p-0" id="benefit-preview">                
              </ul>
            </div>

            <div class="mb-5">
              <h3 class="h5 d-flex align-items-center mb-4 text-info"><span class="icon-book mr-3"></span>Thông tin liên hệ</h3>
              <ul class="list-unstyled m-0 p-0" id="contact-preview">                
              </ul>
            </div>

            <div class="mb-5">
              <h3 class="h5 d-flex align-items-center mb-4 text-info"><span class="icon-turned_in mr-3"></span>Yêu cầu thêm</h3>
              <ul class="list-unstyled m-0 p-0" id="plus-preview">                
              </ul>
            </div>         

          </div>
          <div class="col-lg-5">
            <div class="bg-light p-3 border rounded mb-4">
              <h3 class="text-info  mt-3 h5 pl-3 mb-3 ">Tổng quan</h3>
              <ul class="list-unstyled pl-3 mb-0">
                <!-- <li class="mb-2"><strong class="text-black">Published on:</strong> April 14, 2019</li> -->
                <li class="mb-2" id="job-preview"></li>
                <li class="mb-2" id="rank-preview"></li>
                <li class="mb-2" id="vacancy-preview"></li>
                <li class="mb-2" id="skill-preview"></li>
                <li class="mb-2" id="degree-preview"></li>                
                <li class="mb-2" id="exp-preview"></li>                                
                <li class="mb-2" id="salary-preview"></li>
                <li class="mb-2" id="gender-preview"></li>
                <li class="mb-2" id="region-preview"></li>
                <li class="mb-2" id="status-preview"></li>
                <li class="mb-2" id="probation-preview"></li>
                <li class="mb-2" id="deadline-preview"></li>
              </ul>
            </div>

            <div class="bg-light p-3 border rounded">
              <h3 class="text-info  mt-3 h5 pl-3 mb-3">Yêu cầu trình độ ngoại ngữ</h3>
              <div class="px-3" id="language-preview">               
              </div>
            </div>

            <div class="bg-light p-3 border rounded">
              <h3 class="text-info mt-3 h5 pl-3 mb-3">Yêu cầu trình độ tin học</h3>
              <div class="px-3" id="itech-preview">                
              </div>
            </div>


          </div>
        </div>
      </div>
    </section>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
        <button type="button" class="btn btn-info" onclick="event.preventDefault();
                           document.getElementById('post-job').submit();">          
          <span class="icon-newspaper-o mr-2"></span>Cập nhật tin
        </button>
          
      </div>
    </div>
  </div>
</div>

    <script src="<?php echo e(url('js/job.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>