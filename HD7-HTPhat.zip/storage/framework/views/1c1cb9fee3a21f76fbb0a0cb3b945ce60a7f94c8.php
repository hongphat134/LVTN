
                <footer class="footer">
                     © 2020 <mdi class="mdi mdi-cards-heart text-info"></mdi>HTP<mdi class="mdi mdi-cards-heart text-white"></mdi> - Luận văn tốt nghiệp - Hội đồng 7 - Thầy Trần Văn Hùng - Thầy Lương An Vinh - for STU <mdi class="mdi mdi-cards-heart text-danger"></mdi>.
                </footer>

            </div>
            <!-- End Right content here -->

        </div>
        
        <script src="<?php echo e(asset('admin\js\popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\modernizr.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\detect.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\fastclick.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\jquery.slimscroll.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\jquery.blockUI.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\waves.js')); ?>"></script>
        <!-- Plugin cấm F12 và click right :D -->
        <!-- <script src="<?php echo e(asset('admin\js\wow.min.js')); ?>"></script> -->
        <script src="<?php echo e(asset('admin\js\jquery.nicescroll.js')); ?>"></script>
        <script src="<?php echo e(asset('admin\js\jquery.scrollTo.min.js')); ?>"></script>

        <!--Morris Chart-->
        <!-- <script src="<?php echo e(asset('admin\plugins\morris\morris.min.js')); ?>"></script> -->
        <!-- <script src="<?php echo e(asset('admin\plugins\raphael\raphael-min.js')); ?>"></script> -->

        <!-- <script src="<?php echo e(asset('admin\pages\dashborad.js')); ?>"></script> -->

        <script src="<?php echo e(asset('admin\js\app.js')); ?>"></script>
        <!-- END wrapper -->            

        
    </body>
</html>