<?php $__env->startSection('content'); ?>
<div class="content-page">
<!-- Start content -->
    <div class="content">

        <div class="">
            <div class="page-header-title">
                <h4 class="page-title">Danh sách bài viết</h4>
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <?php echo e(session('success')); ?> <a href="#" class="alert-link">Alert Link</a>.
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <?php echo e(session('error')); ?> <a href="#" class="alert-link">Alert Link</a>.
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="page-content-wrapper">                    
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">                     
                        <div class="card">
                            <?php if(!empty($blog_list)): ?>
                            <div class="card-body">
                                <h4 class="m-b-30 m-t-0">
                                    Danh sách bài viết (Tổng cộng có <?php echo e($blog_list->count()); ?> bài viết)                                 
                                </h4>
                                <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Tiêu đề</th>
                                        <th>Phụ đề</th>
                                        <th>Hình</th>                                        
                                        <th>Ngày tạo</th>
                                        <th>Ngày xử lý</th>
                                        <th>Trạng thái xử lý</th>
                                        <th>Thao tác</th>
                                        <th>Nội dung</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $blog_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($blog->id); ?></td>
                                        <td><?php echo e($blog->tieude); ?></td>
                                        <td><?php echo e($blog->phude); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset('blog_images/'.$blog->hinh)); ?>" alt="Blog Image" style="width: 150px; height: 100px">
                                        </td>               
                                        <td><?php echo e(time_elapsed_string($blog->created_at)); ?></td>
                                        <td><?php echo e(time_elapsed_string($blog->updated_at)); ?></td>
                                        <td>
                                            <?php if($blog->ad_pheduyet == 0): ?> <span class="badge badge-danger">Chưa duyệt</span>
                                            <?php else: ?> <span class="badge badge-success">Đã duyệt</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($blog->ad_pheduyet == 0): ?>
                                            <a class="text-danger" href="<?php echo e(url('administrators/bai-viet/phe-duyet',$blog->id)); ?>">Phê duyệt</a></br>
                                            <?php endif; ?>
                                            <a target="_blank" href="<?php echo e(url('administrators/bai-viet/ds-binh-luan',$blog->id)); ?>">DS bình luận</a>
                                        </td>
                                        <td><?php echo nl2br($blog->noidung); ?></td>                      
                                    </tr>  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                    </tbody>
                                </table>
                            </div>
                            <?php else: ?> <h4>Không có bài viết nào cả!</h4>
                            <?php endif; ?>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>