<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Thông tin nhà tuyển dụng</h1>
            <div class="custom-breadcrumbs">
              <a href="<?php echo e(url('/')); ?>">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Thông tin nhà tuyển dụng</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section block__18514" id="next-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 mr-auto">
            <div class="border p-4 rounded">
              <ul class="list-unstyled block__47528 mb-0">
                <li><span class="active"><h4>Thông tin liên hệ</h4></span></li>
                <li>Tên người liên hệ:<a href="#"> <?php echo e($ntd->tenlh); ?></a></li>
                <li>Email liên hệ:<a href="#"> <?php echo e($ntd->email); ?></a></li>
                <li>SDT liên hệ:<a href="#"> <?php echo e($ntd->sdt); ?></a></li>                
                <?php if($ntd->website): ?>
                <li>Website: <span class="text-danger"><?php echo e($ntd->website); ?></span></li>
                <?php endif; ?>
              </ul>
            </div>
			<?php if(Auth::check()): ?>
            <div class="border p-4 rounded">            	
        		<span class="icon-asterisk mr-2"></span>Bạn có muốn nhận thông báo việc làm mới nhất từ Nhà tuyển dụng này?
        		<hr>
        		 <span class="icon-arrow-right mr-2"></span>
				<?php if(Auth::user()->theodoi_ntd): ?>
					<?php if(in_array($ntd->idUser,json_decode(Auth::user()->theodoi_ntd))): ?>
					<a href="javascript:void(0)" id="<?php echo e($ntd->idUser); ?>" class="btn btn-danger theo-doi">ĐANG THEO DÕI</a>	
					<?php else: ?>
					<a href="javascript:void(0)" id="<?php echo e($ntd->idUser); ?>" class="btn btn-outline-danger theo-doi follow-rec">THEO DÕI</a>
					<?php endif; ?>
				<?php else: ?>
				<a href="javascript:void(0)" id="<?php echo e($ntd->idUser); ?>" class="btn btn-outline-danger theo-doi follow-rec">THEO DÕI</a>
				<?php endif; ?>
		    </div>
		    <script src="<?php echo e(url('ajax/follow-recruiters.js')); ?>"></script>
        <?php else: ?> <strong>Đăng ký trở thành thành viên để có thể nhận thông báo từ nhà tuyển dụng bạn nhé!</strong>
		    <?php endif; ?>
          </div>
						
          <div class="col-lg-8 border" style="background-color: lavender">
            <span class="text-primary d-block mb-5">
              <?php if($ntd->hinh): ?>
            	<img src="<?php echo e(asset('logo/'.$ntd->hinh)); ?>" alt="<?php echo e($ntd->hinh); ?>" class="img-fluid">
              <?php else: ?>
              <img src="<?php echo e(url('logo/default.png')); ?>" alt="Không có hình" class="img-fluid">
              <?php endif; ?>
            </span>
            <h2 class="mb-4">Công ty <?php echo e($ntd->ten); ?></h2>
            <h4>Quy mô dân sự</h4>            
            <p><?php echo e($ntd->quymodansu); ?></p>
            <h4>Văn hoá & phúc lợi</h4>
            <p><?php echo e($ntd->vanhoaphucloi); ?></p>
            <p><strong><span class="text-danger">Địa chỉ:</span><a href="#"> <?php echo e($ntd->diachi); ?>, <?php echo e($ntd->tinhthanhpho); ?></a></strong></p>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section" id="next">
      <div class="container">
        <div class="row mb-5 justify-content-center">
          <div class="col-md-7 text-center">
            <h2 class="section-title mb-2">
              <?php if($job_listings->total() == 0): ?> Rất tiếc! Hiện tại không có tin tuyển dụng nào cả!
              <?php else: ?> Có <?php echo e($job_listings->total()); ?> tin tuyển dụng
              <?php endif; ?>
            </h2>
          </div>
        </div>
        
        <ul class="job-listings mb-5">
          <?php $__currentLoopData = $job_listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="job-listing d-block d-sm-flex pb-3 pb-sm-0 align-items-center">
            <a href="<?php echo e(route('news',$news->id)); ?>"></a>
            <div class="job-listing-logo">
              <?php if($ntd->hinh): ?>
              <img src="<?php echo e(url('logo/'.$ntd->hinh)); ?>" alt="<?php echo e($ntd->hinh); ?>" style="width: 200px; height: 150px">
              <?php else: ?>
              <img src="<?php echo e(url('logo/default.png')); ?>" alt="Không có hình" class="img-fluid">
              <?php endif; ?>
            </div>

            <div class="job-listing-about d-sm-flex custom-width w-100 justify-content-between mx-4">
              <div class="job-listing-position custom-width w-50 mb-3 mb-sm-0">
                <h2><?php echo e($news->nganh); ?></h2>
                <strong>Nhà tuyển dụng <?php echo e($ntd->ten); ?></strong>              
                <div class="keywords">
                  <?php $__currentLoopData = json_decode($news->kinang); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <button class="btn btn-outline-info skill"><?php echo e($skill); ?></button>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                </div>      
              </div>
              <div class="job-listing-location mb-3 mb-sm-0 custom-width w-25">  
                <?php $__currentLoopData = json_decode($news->tinhthanhpho); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="icon-room"></span><?php echo e($city); ?></br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="job-listing-meta">
                <?php if($news->trangthailv == 'Part Time'): ?>
                <span class="badge badge-danger"><?php echo e($news->hinhthuc_lv); ?></span>
                <?php else: ?>
                <span class="badge badge-success"><?php echo e($news->hinhthuc_lv); ?></span>
                <?php endif; ?>
                </br>
                <span class="badge badge-dark">
                Giờ đăng: <?php echo e(time_elapsed_string($news->updated_at)); ?>

                </span>         
                </br>
                <span class="badge badge-info">
                Hạn tuyển dụng: <?php echo e(date('d/m/Y',strtotime($news->hantuyendung))); ?>

                </span>
              </div>
            </div>            
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
        </ul>       
        <?php echo $__env->make('layouts.paginating', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       

      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>