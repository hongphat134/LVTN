<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Chọn hình thức ứng tuyển</h1>
            <div class="custom-breadcrumbs">
              <a href="#">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Chọn hình thức ứng tuyển</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    
    <section class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-5 mb-5">
            <strong>Bạn muốn nộp hồ sơ vào vị trí <span class="text-danger">"<?php echo e($news->nganh); ?>"</span></strong>
            <hr>
            <span class="icon-data_usage mr-2"></span>Vui lòng chọn 1 trong 3 cách dưới đây:</br>

            <h3>Cách 1: <a href="<?php echo e(route('apply',$news->id)); ?>"><button class="btn btn-danger"><span class="icon-file mr-2"></span>Tạo hồ sơ mới</button></a> </h3>
            <span class="icon-hand-o-right mr-2"></span>Lưu ý: Hồ sơ sẽ đến tay nhà tuyển dụng sau khi <span class="text-danger">được duyệt</span>.
            <h3>Cách 2: chọn mẫu hồ sơ</h3>            
            <span class="icon-hand-o-right mr-2"></span>Lưu ý: Nếu mẫu hồ sơ <span class="text-danger">đang chờ duyệt</span> sẽ đến tay nhà tuyển dụng sau khi được duyệt.
            <h3>Cách 3: copy mẫu hồ sơ</h3>             
          
            <div class="border p-3 round" style="background-color: lavender; margin-top: 15px;">
                Bạn gặp khó khăn?</br> Liên hệ hotline hỗ trợ Người tim việc:</br>
              Giờ hành chính: miền Bắc (028) 5407 0399, miền Nam (093) 8922 315 hoặc liên hệ tới email <strong><?php echo e(config('mail.username')); ?></strong>
            </div>             
          </div>

          <div class="col-lg-7 mb-5">
            <h2 class="mb-4 text-center"><span class="icon-file-text-o mr-2"></span>Hồ sơ của bạn (Có <?php echo e($profiles->total()); ?> mẫu)</h2>
            <?php if(!empty($profiles->toArray())): ?>
            <form class="p-5 border rounded" method="get" 
            action="<?php echo e(url('/nguoitimviec/nop-ho-so')); ?>">
            	<?php if(session('error')): ?>
    					<div class="alert alert-danger alert-dismissible fade show">
    					  <button type="button" class="close" data-dismiss="alert">&times;</button>
    					  <?php echo e(session('error')); ?>

    					</div>            		
            	<?php endif; ?>
				
            	<?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<div class="p-4 border rounded">
            		<h4><input type="radio" name="profile" value="<?php echo e($profile->id); ?>"> <?php echo e($profile->nganh); ?></h4>					
      				  <?php if($profile->ad_pheduyet == 1): ?>
                <span class="badge badge-success">Hồ sơ đã được duyệt</span> 
                <?php else: ?> 
                <span class="badge badge-danger">Hồ sơ chưa được duyệt</span> 
                <?php endif; ?>

                - <a data-toggle="modal" data-target="#viewModal<?php echo e($profile->id); ?>" href="javascript:void(0)"><strong>Xem hồ sơ</strong></a> 
      					-	<label for="lname">Ngày cập nhật: <?php echo e(date('d/m/Y',strtotime($profile->updated_at))); ?></label>              
            	</div> 

              
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div style="margin-top: 20px;">
            <?php echo $__env->make('layouts.paginating',['job_listings' => $profiles], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
            </div>
				      <input type="hidden" value="<?php echo e($news->id); ?>" name="ttd_id">
            	<button name="filed" value="filed" class="btn btn-primary"><span class="icon-check mr-2"></span>Nộp hồ sơ</button>
              <button name="copy" value="copy" class="btn btn-dark"><span class="icon-content_copy mr-2"></span>Copy hồ sơ</button>
            </form>
            <?php endif; ?>                         
                  
          </div>  
          
                                         
        </div>

      </div>
    </section>

    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="viewModal<?php echo e($profile->id); ?>" tabindex="-1">
      <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">          
          <div class="row">
          <div class="col-lg-4 mr-auto">
            <div class="border p-3 rounded">
              <ul class="list-unstyled block__47528 mb-0">
                <li><span class="active"><h3><?php echo e($profile->nganh); ?></h3></span></li>
                <li>Họ & tên: <a href="#"><?php echo e($profile->hoten); ?></a></li>
                <li>Giới tính: <a href="#"><?php echo e($profile->gioitinh); ?></a></li>
                <li>Ngày sinh: <a href="#"><?php echo e(date('d/m/Y',strtotime($profile->ngaysinh))); ?></a></li>
                <li>Email: <a href="#"><?php echo e($profile->emaillienhe); ?></a></li>
                <li>SDT liên hệ: <a href="#"><?php echo e($profile->sdtlienhe); ?></a></li>
                <li>Khu vực: <a href="#"><?php echo e($profile->khuvuc); ?></a></li>
                <li>Hôn nhân: <a href="#"><?php echo e($profile->honnhan); ?></a></li>
                <li>Hình thức làm việc mong muốn: <a href="#"><?php echo e($profile->hinhthuc_lv); ?></a></li>
                <li>Mức lương mong muốn: <a href="#"><?php echo e($profile->mucluongmm); ?></a></li>
                <li>Bằng cấp: <a href="#"><?php echo e($profile->bangcap); ?></a></li>
                <li>Cấp bậc: <a href="#"><?php echo e($profile->capbac); ?></a></li>
                <li>Kinh Nghiệm: <a href="#"><?php echo e($profile->kinhnghiem); ?></a></li>              
                <li><span class="text-info">Trạng thái: </span>
                  <a href="#">
                  <?php if($profile->congkhai == 1): ?> <span class="badge badge-info">Công khai</span>
                  <?php else: ?> <span class="badge badge-danger">Chưa công khai</span>
                  <?php endif; ?>
                  </a>
                </li>
                <?php if($profile->ad_pheduyet == 1): ?>
                <li><span class="text-danger">Lượt xem: <?php echo e($profile->luotxem); ?></span></li>
                <?php endif; ?>
              </ul>
            </div>

            <div class="border p-4 rounded">
            <h3>Kĩ năng</h3>
            <?php $__currentLoopData = json_decode($profile->kinang); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kinang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><span class="icon-hand-o-right"> <?php echo e($kinang); ?></span></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php if($profile->ngoaingu): ?>
            <div class="border p-4 rounded">
            <h3>Ngoại ngữ</h3>
            <?php $__currentLoopData = json_decode($profile->ngoaingu); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ngoaingu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><span class="icon-language mx-2"> <?php echo e($ngoaingu); ?></span></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <?php if($profile->tinhoc): ?>
            <div class="border p-4 rounded">
            <h3>Tin học</h3>
            <?php $__currentLoopData = json_decode($profile->tinhoc); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tinhoc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><span class="icon-caret-right mr-2"> <?php echo e($tinhoc); ?></span></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
          </div>
          <div class="col-lg-8">
            <span class="text-primary d-block mb-5">
              <span class="icon-search display-1"></span>
              <span class="icon-star display-1"></span>
              <span class="icon-files-o display-1"></span>
              <span class="icon-file-text-o display-1"></span>
              <span class="icon-file-text display-1"></span>
              <span class="icon-file display-1"></span>
              <span class="icon-file-word-o display-1"></span>
              <span class="icon-insert_drive_file display-1"></span>
            </span>
            <?php if($profile->hinh): ?>
            <img src="<?php echo e(asset('hinhdaidien/'.$profile->hinh)); ?>" alt="<?php echo e($profile->hinh); ?>" style="width: 200px; height: 200px">
            <?php else: ?>
            <img src="<?php echo e(asset('hinhdaidien/default.png')); ?>" alt="Chưa có hình">
            <?php endif; ?>
            <h2 class="mb-4">Mục tiêu</h2>
            <p>
              <?php echo $profile->muctieu ? nl2br($profile->muctieu) : 'Bạn để trống mục này!'; ?>

            </p>           
            <h2 class="mb-4">Sở trường</h2>          
            <p>
              <?php echo $profile->sotruong ? nl2br($profile->sotruong) : 'Bạn để trống mục này!'; ?>

            </p>
            <h2 class="mb-4">Thông tin thêm</h2>
            <p>
              <?php echo $profile->thongtinthem ? nl2br($profile->thongtinthem) : 'Bạn để trống mục này!'; ?>

            </p>            
            <p>
              <a href="javascript::void(0)" class="btn btn-primary btn-md mt-4">Ngày đăng: <?php echo e(time_elapsed_string($profile->created_at)); ?></a>
              <a href="javascript::void(0)" class="btn btn-primary btn-md mt-4">Ngày cập nhật: <?php echo e(time_elapsed_string($profile->updated_at)); ?></a>
            </p>

          </div>
        </div>
          <div class="modal-footer">           
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
          </div>
        </div>
      </div>
    </div>  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>