<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- MENU -->
    <?php if(Auth::check()): ?> <?php echo $__env->make('ntv_layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
    <?php else: ?> <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>     
    <!-- HOME -->
    <?php echo $__env->make('layouts.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="site-section" id="next">
      <div class="container">

        <div class="row mb-5 justify-content-center">
          <div class="col-md-7 text-center">
            <h2 class="section-title mb-2">
              <?php if($job_listings->total() == 0): ?> Rất tiếc! Hiện tại không có tin tuyển dụng nào cả!
              <?php else: ?> Có <?php echo e($job_listings->total()); ?> tin tuyển dụng
              <?php endif; ?>
            </h2>
          </div>
        </div>
        
        <ul class="job-listings mb-5">
          <?php $__currentLoopData = $job_listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="job-listing d-block d-sm-flex pb-3 pb-sm-0 align-items-center">
            <a href="<?php echo e(route('news',$news->id)); ?>"></a>
            <div class="job-listing-logo">
              <?php if($news->hinh): ?>
              <img src="<?php echo e(url('logo/'.$news->hinh)); ?>" alt="<?php echo e($news->hinh); ?>" style="width: 200px; height: 150px">
              <?php else: ?>
              <img src="<?php echo e(url('logo/default.png')); ?>" alt="<?php echo e($news->hinh); ?>" class="img-fluid">
              <?php endif; ?>
            </div>

            <div class="job-listing-about d-sm-flex custom-width w-100 justify-content-between mx-4">
              <div class="job-listing-position custom-width w-50 mb-3 mb-sm-0">
                <h2><?php echo e($news->nganh); ?></h2>
                <strong>Nhà tuyển dụng <?php echo e($news->ten); ?></strong>              
                <div class="keywords">
                  <?php $__currentLoopData = json_decode($news->kinang); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <button class="btn btn-outline-info skill"><?php echo e($skill); ?></button>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                </div>      
              </div>
              <div class="job-listing-location mb-3 mb-sm-0 custom-width w-25">  
                <?php $__currentLoopData = json_decode($news->tinhthanhpho); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="icon-room"></span><?php echo e($city); ?></br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="job-listing-meta">
                <?php if($news->hinhthuc_lv == 'Part Time'): ?>
                <span class="badge badge-danger"><?php echo e($news->hinhthuc_lv); ?></span>
                <?php else: ?>
                <span class="badge badge-success"><?php echo e($news->hinhthuc_lv); ?></span>
                <?php endif; ?>
                </br>
                <span class="badge badge-dark">
                Mức lương: <?php echo e($news->mucluong); ?>

                </span>         
                </br>
                <span class="badge badge-info">
                Hạn tuyển dụng: <?php echo e(date('d/m/Y',strtotime($news->hantuyendung))); ?>

                </span>
              </div>
            </div>            
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
        </ul>       
        <?php echo $__env->make('layouts.paginating', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       

      </div>
    </section>
    <!-- TÔ ĐẬM Search Result => Cần cải tiến-->
    <script>      
        var search = $("#search").val();
        // console.log(search);
        var s = $("body .job-listing-position h2");
        
        $.each(s,function(k,v){
          var regex = new RegExp(search, "i");
          var str = v.innerText;
          if (str.search(regex) != -1) {  
             v.innerHTML = str.replace(regex, "<b style='background-color:red'>$&</b>");
          }
          // console.log(v);
        });          
    </script>
    <?php echo $__env->make('layouts.looking-job', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>