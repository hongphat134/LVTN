<?php $__env->startSection('content'); ?>
    <!-- MODAL FORM DELETE -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Xoá mẫu hồ sơ</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            Bạn có chắc chắn muốn xoá mẫu hồ sơ này không?
          </div>
          <div class="modal-footer">
            <a id="delete" href="#"><button type="button" class="btn btn-primary">Đồng ý</button></a>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
          </div>
        </div>
      </div>
    </div>

    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Tủ hồ sơ</h1>
            <div class="custom-breadcrumbs">
              <a href="#">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Tủ hồ sơ</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section services-section bg-light block__62849">
      <div class="container">
        <?php if(session('success')): ?>
         <div class="alert alert-success alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Hoàn tất!</strong> <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        
        <div class="row">
          <?php $__currentLoopData = $profile_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-6 col-md-6 col-lg-4 mb-4 mb-lg-5">           
            <a class="block__16443 text-center d-block" data-toggle="modal" data-target="#viewModal<?php echo e($key); ?>" href="javascript:void(0)">
            <?php if($profile->congkhai == 1): ?>
            <div class="ribbon-right-wrapper">
              <div class="ribbon-right blue">Public</div>  
            </div>
            <?php endif; ?>
            <?php if($profile->ad_pheduyet == 1): ?>
            <div class="ribbon-wrapper">
              <div class="ribbon red">Duyệt</div>  
            </div>
            <?php endif; ?>
              <span class="custom-icon mx-auto"><span class="icon-file-text d-block"></span></span>
              <h3><?php echo e($profile->nganh); ?> </h3>
              <p>Họ & tên: <?php echo e($profile->hoten); ?></p>
              <?php if($profile->ad_pheduyet == 1): ?>              
              <p>Lượt xem: <?php echo e($profile->luotxem); ?></p>  
              <?php else: ?>
              <p><span class="badge badge-pill badge-danger">Đang chờ duyệt</span></p>
              <?php endif; ?>
              <p>Ngày cập nhật: <?php echo e(date('d/m/Y',strtotime($profile->updated_at))); ?></p>            
            </a>
            
            <div class="row">
              <span class="col-7">
                <div class="dropdown">
  <button class="btn btn-outline-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <i class="icon-th-large"></i> Quản lý mẫu hồ sơ
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">   
    <a class="dropdown-item" href="<?php echo e(url('nguoitimviec/update-profile',$profile->id)); ?>" target="_blank">Cập nhật mẫu</a>
    <a class="dropdown-item" href="<?php echo e(route('pdf-profile',$profile->id)); ?>" target="_blank">Xuất PDF</a>
    <a class="dropdown-item call-delete" id="<?php echo e($profile->id); ?>" data-toggle="modal" data-target="#deleteModal" href="javascript:void(0)">Xoá</a>
  </div>
</div>             
              </span>
              <span class="col-5">                
              <a href="<?php echo e(url('/nguoitimviec/set-status',$profile->id)); ?>"><button class="btn btn-outline-info"><i class="icon-public"></i> <?php echo e($profile->congkhai == 0 ? 'Bật':'Tắt'); ?> Public</button></a>
              </span> 
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <script>
            $(".call-delete").click(function(){
                // console.log($(this).attr('id'));
                var id = $(this).attr('id');
                          
                $("#delete").attr('href', '/nguoitimviec/delete-profile/' + id);
            });
          </script>    
        </div>
        <!-- ROW -->
         <?php echo $__env->make('layouts.paginating',['job_listings' => $profile_list], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <!-- CONTAINER -->

    </section>
  
  <!-- VIEW PROFILE -->
  <?php $__currentLoopData = $profile_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <!-- MODAL FORM VIEW -->
    <div class="modal fade" id="viewModal<?php echo e($key); ?>" tabindex="-1">
      <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">          
          <div class="row">
          <div class="col-lg-4 mr-auto">
            <div class="border p-3 rounded">
              <ul class="list-unstyled block__47528 mb-0">
                <li><span class="active"><h3><?php echo e($profile->nganh); ?></h3></span></li>
                <li>Họ & tên: <a href="#"><?php echo e($profile->hoten); ?></a></li>
                <li>Giới tính: <a href="#"><?php echo e($profile->gioitinh); ?></a></li>
                <li>Ngày sinh: <a href="#"><?php echo e(date('d/m/Y',strtotime($profile->ngaysinh))); ?></a></li>
                <li>Email: <a href="#"><?php echo e($profile->emaillienhe); ?></a></li>
                <li>SDT liên hệ: <a href="#"><?php echo e($profile->sdtlienhe); ?></a></li>
                <li>Khu vực: <a href="#"><?php echo e($profile->khuvuc); ?></a></li>
                <li>Hôn nhân: <a href="#"><?php echo e($profile->honnhan); ?></a></li>
                <li>Hình thức làm việc mong muốn: <a href="#"><?php echo e($profile->hinhthuc_lv); ?></a></li>
                <li>Mức lương mong muốn: <a href="#"><?php echo e($profile->mucluongmm); ?></a></li>
                <li>Bằng cấp: <a href="#"><?php echo e($profile->bangcap); ?></a></li>
                <li>Cấp bậc: <a href="#"><?php echo e($profile->capbac); ?></a></li>
                <li>Kinh Nghiệm: <a href="#"><?php echo e($profile->kinhnghiem); ?></a></li>              
                <li><span class="text-info">Trạng thái: </span>
                  <a href="#">
                  <?php if($profile->congkhai == 1): ?> <span class="badge badge-info">Công khai</span>
                  <?php else: ?> <span class="badge badge-danger">Chưa công khai</span>
                  <?php endif; ?>
                  </a>
                </li>
                <?php if($profile->ad_pheduyet == 1): ?>
                <li><span class="text-danger">Lượt xem: <?php echo e($profile->luotxem); ?></span></li>
                <?php endif; ?>
              </ul>
            </div>

            <div class="border p-4 rounded">
            <h3>Kĩ năng</h3>
            <?php $__currentLoopData = json_decode($profile->kinang); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kinang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><span class="icon-hand-o-right"> <?php echo e($kinang); ?></span></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php if($profile->ngoaingu): ?>
            <div class="border p-4 rounded">
            <h3>Ngoại ngữ</h3>
            <?php $__currentLoopData = json_decode($profile->ngoaingu); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ngoaingu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><span class="icon-language mx-2"> <?php echo e($ngoaingu); ?></span></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <?php if($profile->tinhoc): ?>
            <div class="border p-4 rounded">
            <h3>Tin học</h3>
            <?php $__currentLoopData = json_decode($profile->tinhoc); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tinhoc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><span class="icon-caret-right mr-2"> <?php echo e($tinhoc); ?></span></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

          </div>
          <div class="col-lg-8">
            <span class="text-primary d-block mb-5">
              <span class="icon-search display-1"></span>
              <span class="icon-star display-1"></span>
              <span class="icon-files-o display-1"></span>
              <span class="icon-file-text-o display-1"></span>
              <span class="icon-file-text display-1"></span>
              <span class="icon-file display-1"></span>
              <span class="icon-file-word-o display-1"></span>
              <span class="icon-insert_drive_file display-1"></span>
            </span>
            <?php if($profile->hinh): ?>
            <img src="<?php echo e(asset('hinhdaidien/'.$profile->hinh)); ?>" alt="<?php echo e($profile->hinh); ?>" style="width: 200px; height: 200px">
            <?php else: ?>
            <img src="<?php echo e(asset('hinhdaidien/default.png')); ?>" alt="Chưa có hình">
            <?php endif; ?>
            <h2 class="mb-4">Mục tiêu</h2>
            <p>
              <?php echo $profile->muctieu ? nl2br($profile->muctieu) : 'Bạn để trống mục này!'; ?>

            </p>           
            <h2 class="mb-4">Sở trường</h2>          
            <p>
              <?php echo $profile->sotruong ? nl2br($profile->sotruong) : 'Bạn để trống mục này!'; ?>

            </p>
            <h2 class="mb-4">Thông tin thêm</h2>
            <p>
              <?php echo $profile->thongtinthem ? nl2br($profile->thongtinthem) : 'Bạn để trống mục này!'; ?>

            </p>            
            <p>
              <a href="javascript::void(0)" class="btn btn-primary btn-md mt-4">Ngày đăng: <?php echo e(time_elapsed_string($profile->created_at)); ?></a>
              <a href="javascript::void(0)" class="btn btn-primary btn-md mt-4">Ngày cập nhật: <?php echo e(time_elapsed_string($profile->updated_at)); ?></a>
            </p>

          </div>
        </div>
          <div class="modal-footer">           
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>