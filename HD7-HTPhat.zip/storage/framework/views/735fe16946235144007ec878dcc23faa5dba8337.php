<!-- ========== Left Sidebar Start ========== -->
            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">                    
                    <!--- Divider -->
                    <div id="sidebar-menu">
                        <ul>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-newspaper"></i> <span> Tin tuyển dụng </span> <span class="float-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/administrators/tin-tuyen-dung/danh-sach')); ?>">Danh sách</a></li>
                                    <li><a href="<?php echo e(url('/administrators/tin-tuyen-dung/phe-duyet')); ?>">Phê duyệt</a></li>                                    
                                </ul>
                            </li>

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-file-account"></i> <span> Hồ sơ </span> <span class="float-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/administrators/ho-so/danh-sach')); ?>">Danh sách</a></li>
                                    <li><a href="<?php echo e(url('/administrators/ho-so/phe-duyet')); ?>">Phê duyệt</a></li>
                                    <li><a href="<?php echo e(url('/administrators/ho-so/ung-tuyen')); ?>">Phê duyệt HSXV</a></li>                                    
                                </ul>
                            </li>
                            
                            <li>
                                <a href="<?php echo e(url('/administrators/lien-he')); ?>" class="waves-effect"><i class="mdi mdi-contact-mail"></i><span> Liên hệ <span class="badge badge-pill badge-primary float-right">1</span></span></a>
                            </li>

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-blogger"></i> <span> Bài viết </span> <span class="float-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/administrators/bai-viet/danh-sach')); ?>">Danh sách</a></li>                                    
                                </ul>
                            </li>

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-account"></i> <span> Người dùng </span> <span class="float-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/administrators/nguoi-dung/nguoi-tim-viec')); ?>">Người tìm việc</a></li>
                                    <li><a href="<?php echo e(url('/administrators/nguoi-dung/nha-tuyen-dung')); ?>">Nhà tuyển dụng</a></li>   
                                    <li><a href="<?php echo e(url('/administrators/nguoi-dung/quan-tri-vien')); ?>">Quản trị viên</a></li>          
                                </ul>
                            </li>

                            <li>
                                <a href="<?php echo e(url('/administrators/thu-thap-y-kien/danh-sach')); ?>" class="waves-effect"><i class="mdi mdi-arch"></i><span> Thu thập ý kiến <span class="badge badge-pill badge-primary float-right">9</span></span></a>
                            </li>
                        </ul>
                    </div>
                    <div class="clearfix"></div>
                </div> <!-- end sidebarinner -->
            </div>
            <!-- Left Sidebar End -->