<pre>
Chào bạn, <?php echo e($ntv->ten); ?>!
Nhà tuyển dụng <a href="<?php echo e(config('app.url')); ?>/thong-tin-ntd/<?php echo e($ntd->id); ?>"><?php echo e($ntd->ten); ?></a> đã ngỏ ý đến hồ sơ mà bạn công khai!

<label for="content">Nội dung gửi:</label>
<?php echo e($content); ?>


Cảm ơn bạn đã tin tưởng và lựa chọn website tuyển dụng <?php echo e(config('app.url')); ?>. Chúc bạn sớm tìm được việc làm như mong muốn.
Nếu bạn cần hỗ trợ, vui lòng liên hệ tới email <?php echo e(config('mail.username')); ?> hoặc gọi tới hotline Miền Nam: (028) 5407 0399 và Miền Bắc: (093) 8922 315.
<strong><?php echo e(config('app.name')); ?></strong> chúc bạn sớm tìm được công việc như ý.
</pre>