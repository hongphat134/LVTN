<?php $__env->startSection('content'); ?>
<!-- DataTables -->
<link href="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/plugins/datatables/fixedHeader.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/plugins/datatables/responsive.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/plugins/datatables/scroller.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">

<div class="content-page">
<!-- Start content -->
	<div class="content">

	    <div class="">
	        <div class="page-header-title">
	            <h4 class="page-title">Tin tuyển dụng</h4>
	        </div>
	    </div>

		<div class="page-content-wrapper">                    
			<div class="container-fluid">
				<div class="row">
				    <div class="col-lg-12">
				        <div class="card">
				            <div class="card-body">
				                <h4 class="m-b-30 m-t-0">Quản lý tin tuyển dụng</h4>
				                <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
				                    <thead>
				                    <tr>
				                        <th>First name</th>
				                        <th>Last name</th>
				                        <th>Position</th>
				                        <th>Office</th>
				                        <th>Age</th>
				                        <th>Start date</th>
				                        <th>Salary</th>
				                        <th>Extn.</th>
				                        <th>E-mail</th>				                        
				                    </tr>
				                    </thead>
				                    <tbody>
				                    <tr>
				                        <td>Tiger</td>
				                        <td>Nixon</td>
				                        <td>System Architect</td>
				                        <td>Edinburgh</td>
				                        <td>61</td>
				                        <td>2011/04/25</td>
				                        <td>$320,800</td>
				                        <td>5421</td>
				                        <td>t.nixon@datatables.net</td>
				                    </tr>
				                    <tr>
		                                <td>Garrett</td>
		                                <td>Winters</td>
		                                <td>Accountant</td>
		                                <td>Tokyo</td>
		                                <td>63</td>
		                                <td>2011/07/25</td>
		                                <td>$170,750</td>
		                                <td>8422</td>
		                                <td>g.winters@datatables.net</td>
		                            </tr>
		                            <tr>
		                                <td>Ashton</td>
		                                <td>Cox</td>
		                                <td>Junior Technical Author</td>
		                                <td>San Francisco</td>
		                                <td>66</td>
		                                <td>2009/01/12</td>
		                                <td>$86,000</td>
		                                <td>1562</td>
		                                <td>a.cox@datatables.net</td>
		                            </tr>
		                            <tr>
		                                <td>Cedric</td>
		                                <td>Kelly</td>
		                                <td>Senior Javascript Developer</td>
		                                <td>Edinburgh</td>
		                                <td>22</td>
		                                <td>2012/03/29</td>
		                                <td>$433,060</td>
		                                <td>6224</td>
		                                <td>c.kelly@datatables.net</td>
		                            </tr>
		                            <tr>
		                                <td>Airi</td>
		                                <td>Satou</td>
		                                <td>Accountant</td>
		                                <td>Tokyo</td>
		                                <td>33</td>
		                                <td>2008/11/28</td>
		                                <td>$162,700</td>
		                                <td>5407</td>
		                                <td>a.satou@datatables.net</td>
		                            </tr>
		                            <tr>
		                                <td>Brielle</td>
		                                <td>Williamson</td>
		                                <td>Integration Specialist</td>
		                                <td>New York</td>
		                                <td>61</td>
		                                <td>2012/12/02</td>
		                                <td>$372,000</td>
		                                <td>4804</td>
		                                <td>b.williamson@datatables.net</td>
		                            </tr>
		                            <tr>
		                                <td>Doris</td>
		                                <td>Wilder</td>
		                                <td>Sales Assistant</td>
		                                <td>Sidney</td>
		                                <td>23</td>
		                                <td>2010/09/20</td>
		                                <td>$85,600</td>
		                                <td>3023</td>
		                                <td>d.wilder@datatables.net</td>
		                            </tr>
		                            <tr>
		                                <td>Angelica</td>
		                                <td>Ramos</td>
		                                <td>Chief Executive Officer (CEO)</td>
		                                <td>London</td>
		                                <td>47</td>
		                                <td>2009/10/09</td>
		                                <td>$1,200,000</td>
		                                <td>5797</td>
		                                <td>a.ramos@datatables.net</td>
		                            </tr>
		                            <tr>
		                                <td>Gavin</td>
		                                <td>Joyce</td>
		                                <td>Developer</td>
		                                <td>Edinburgh</td>
		                                <td>42</td>
		                                <td>2010/12/22</td>
		                                <td>$92,575</td>
		                                <td>8822</td>
		                                <td>g.joyce@datatables.net</td>
		                            </tr>
		                            <tr>
		                                <td>Jennifer</td>
		                                <td>Chang</td>
		                                <td>Regional Director</td>
		                                <td>Singapore</td>
		                                <td>28</td>
		                                <td>2010/11/14</td>
		                                <td>$357,650</td>
		                                <td>9239</td>
		                                <td>j.chang@datatables.net</td>
		                            </tr>
		                            <tr>
		                                <td>Brenden</td>
		                                <td>Wagner</td>
		                                <td>Software Engineer</td>
		                                <td>San Francisco</td>
		                                <td>28</td>
		                                <td>2011/06/07</td>
		                                <td>$206,850</td>
		                                <td>1314</td>
		                                <td>b.wagner@datatables.net</td>
		                            </tr>
		                            <tr>
		                                <td>Fiona</td>
		                                <td>Green</td>
		                                <td>Chief Operating Officer (COO)</td>
		                                <td>San Francisco</td>
		                                <td>48</td>
		                                <td>2010/03/11</td>
		                                <td>$850,000</td>
		                                <td>2947</td>
		                                <td>f.green@datatables.net</td>
		                            </tr>
		                            <tr>
		                                <td>Shou</td>
		                                <td>Itou</td>
		                                <td>Regional Marketing</td>
		                                <td>Tokyo</td>
		                                <td>20</td>
		                                <td>2011/08/14</td>
		                                <td>$163,000</td>
		                                <td>8899</td>
		                                <td>s.itou@datatables.net</td>
		                            </tr>
				                	</tbody>
				                </table>
				            </div>
				         </div>
				    </div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Required datatable js-->
<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<!-- Buttons examples -->
<script src="<?php echo e(asset('admin/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/plugins/datatables/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables/dataTables.fixedHeader.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables/dataTables.keyTable.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables/dataTables.scroller.min.js')); ?>"></script>

<!-- Responsive examples -->
<script src="<?php echo e(asset('admin/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>

<!-- Datatable init js -->
<!-- <script src="<?php echo e(asset('admin/pages/datatables.init.js')); ?>"></script> -->
<script>
	$(document).ready(function(){
		$("#datatable-responsive").DataTable({
            fixedHeader: !0,
            dom: "Bfrtip",
            buttons: [{
                extend: "copy",
                className: "btn-primary"
            }, {
                extend: "csv",
                className: "btn-primary"
            }, {
                extend: "excel",
                className: "btn-primary"
            }, {
                extend: "pdf",
                className: "btn-primary"
            }, {
                extend: "print",
                className: "btn-primary"
            }],            
        });
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>