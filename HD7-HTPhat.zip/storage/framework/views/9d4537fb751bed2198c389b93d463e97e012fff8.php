<?php $__env->startSection('content'); ?>
<div class="content-page">
<!-- Start content -->
    <div class="content">

        <div class="">
            <div class="page-header-title">
                <h4 class="page-title">Danh sách quản trị viên</h4>
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <?php echo e(session('success')); ?> <a href="#" class="alert-link">Alert Link</a>.
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <?php echo e(session('error')); ?> <a href="#" class="alert-link">Alert Link</a>.
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="page-content-wrapper">                    
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">                     
                        <div class="card">
                            <?php if(!empty($user_list)): ?>
                            <div class="card-body">
                                <h4 class="m-b-30 m-t-0">
                                    Danh sách quản trị viên (Tổng cộng có <?php echo e($user_list->count()); ?> tài khoản)                                 
                                </h4>
                                <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Tên</th>                                 
                                        <th>Email</th>                                        
                                        <th>Ngày tạo</th>
                                        <th>Ngày cập nhật</th>
                                        <th>Thao tác</th>  
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->ten); ?></td>
                                        <td><?php echo e($user->email); ?></td>                                        
                                        <td><?php echo e(date('h:i:s d/m/Y',strtotime($user->created_at))); ?></td>
                                        <td><?php echo e(date('h:i:s d/m/Y',strtotime($user->updated_at))); ?></td>
                                        <td>
                                            <a href="#"><i class="mdi mdi-table-search"></i></a>
                                            <a href="#"><i class="mdi mdi-delete-circle"></i></a>
                                            <a href="#"><i class="mdi mdi-calendar-edit"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                    </tbody>
                                </table>
                            </div>
                            <?php else: ?> <h4>Không có bình luận nào cả!</h4>
                            <?php endif; ?>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>