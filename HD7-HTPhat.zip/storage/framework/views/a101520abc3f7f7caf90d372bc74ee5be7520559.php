<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<style>
		*{
			font-family: DejaVu Sans;			
		}
		table{
			width: 100%;	
			text-align: center;		
		}
		td:first-child{
			background-color: #EECFC4;
		}
	</style>	
	<h1 style="text-align: center;">Hồ sơ xin việc</h1>	
	<div class="container">		
		<table border="1">
			<tr>
				<td>Hình đại diện</td>
				<td>
					<?php if($profile->hinh): ?>
					<img src="<?php echo e(asset('hinhdaidien/'.$profile->hinh)); ?>" alt="<?php echo e($profile->hinh); ?>" style="width: 150px; height: 150px">
					<?php else: ?>
					<img src="<?php echo e(asset('hinhdaidien/default.png')); ?>" alt="<?php echo e($profile->hinh); ?>">
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<td>Họ tên</td>
				<td><?php echo e($profile->hoten); ?></td>
			</tr>
			<tr>
				<td>Ngày sinh</td>
				<td><?php echo e(date('d/m/Y',strtotime($profile->ngaysinh))); ?></td>
			</tr>
			<tr>
				<td>Giới tính</td>
				<td><?php echo e($profile->gioitinh); ?></td>
			</tr>
			<tr>
				<td>Email liên hệ</td>
				<td><?php echo e($profile->emaillienhe); ?></td>
			</tr>
			<tr>
				<td>SDT liên hệ</td>
				<td><?php echo e($profile->sdtlienhe); ?></td>
			</tr>
			<tr>
				<td>Ngành nghề</td>
				<td><?php echo e($profile->nganh); ?></td>
			</tr>
			<tr>
				<td>Kĩ năng</td>
				<td>
					<?php $__currentLoopData = json_decode($profile->kinang); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php echo e($skill); ?> /
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>					
				</td>
			</tr>
			<tr>
				<td>Khu vực</td>
				<td><?php echo e($profile->khuvuc); ?></td>
			</tr>
			<tr>
				<td>Tình trạng hôn nhân</td>
				<td><?php echo e($profile->honnhan); ?></td>
			</tr>
			<tr>
				<td>Hình thức làm việc</td>
				<td><?php echo e($profile->hinhthuc_lv); ?></td>
			</tr>
			<tr>
				<td>Bằng cấp cao nhất</td>
				<td><?php echo e($profile->bangcap); ?></td>
			</tr>
			<tr>
				<td>Cấp bậc cao nhất</td>
				<td><?php echo e($profile->capbac); ?></td>
			</tr>
			<tr>
				<td>Kinh nghiệm</td>
				<td><?php echo e($profile->kinhnghiem); ?></td>
			</tr>
			<tr>
				<td>Mức lương mong muốn</td>
				<td style="background-color: brown; color:lavender"><?php echo e($profile->mucluongmm); ?></td>
			</tr>
			<tr>
				<td>Ngoại ngữ</td>
				<td>
					<?php if($profile->ngoaingu): ?>
						<?php $__currentLoopData = json_decode($profile->ngoaingu); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php echo e($language); ?> &
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>					
				</td>
			</tr>
			<tr>
				<td>Tin học</td>
				<td>
					<?php if($profile->tinhoc): ?>
						<?php $__currentLoopData = json_decode($profile->tinhoc); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php echo e($itech); ?> $
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>	
				</td>
			</tr>
			<tr>
				<td>Mục tiêu</td>
				<td><?php echo nl2br($profile->muctieu); ?></td>
			</tr>
			<tr>
				<td>Sở trường</td>
				<td><?php echo nl2br($profile->muctieu); ?></td>
			</tr>
			<tr>
				<td>Thông tin thêm</td>
				<td><?php echo nl2br($profile->thongtinthem); ?></td>
			</tr>
		</table>		
	</div>
</body>
</html>