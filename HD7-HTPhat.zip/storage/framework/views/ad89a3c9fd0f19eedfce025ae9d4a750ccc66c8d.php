<!doctype html>
<html lang="en">
  <head>
    <title>HTP &mdash; My Website</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="Free-Template.co" />
    <!-- <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" /> -->
    <link rel="shortcut icon" href="<?php echo e(url('favicon.png')); ?>">
    
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/custom-bs.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.fancybox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/icomoon/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/line-icons/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <!-- JS -->

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/stickyfill.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.fancybox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.easing.1.3.js')); ?>"></script>    
    <script src="<?php echo e(asset('js/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.animateNumber.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>  
    <script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script> 
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

    <!-- MAIN CSS -->
            
  </head>
  <body id="top">

  <div id="overlayer"></div>
  <div class="loader">
    <div class="spinner-border text-primary" role="status">
      <span class="sr-only">Loading...</span>
    </div>
  </div>