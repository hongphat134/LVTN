<section class="section-hero home-section overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">

      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-12">
            <div class="mb-5 text-center">
              <h1 class="text-white font-weight-bold">Cách nhanh nhất để tìm kiếm nhân lực</h1>
              <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, quas fugit ex!</p> -->
            </div>
            <form method="get" class="search-jobs-form" action="<?php echo e(url('/nhatuyendung/tim-kiem')); ?>">
              <div class="row mb-5">
                <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
                  <input id="search" name="key" type="text" class="form-control form-control-lg" placeholder="ngành, kỹ năng..." 
                  value="<?php if(isset($search_info)): ?><?php echo e($search_info['key']); ?><?php endif; ?>">

                  <ul class="list-group" id="job-skill-autocomplete">       
                  </ul>                               
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
                  <!-- Multi -->
                  <select name="region[]" class="selectpicker" data-style="btn-white btn-lg" data-width="100%" data-live-search="true" title="Chọn khu vực..." data-size="10" data-max-options="3" multiple>
                  <?php $__currentLoopData = $region_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region => $city_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <optgroup label="<?php echo e($region == 'MienNam' ? 'Miền Nam' : ($region == 'MienBac' ? 'Miền Bắc' : 'Miền Trung')); ?>">
                  <?php if(isset($search_info)): ?>
                    <?php if(isset($search_info['region'])): ?>          
                      <?php $__currentLoopData = $city_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option <?php echo e(in_array($city->Ten,$search_info['region']) ? 'selected' : ''); ?>>
                        <?php echo e($city->Ten); ?>

                      </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                      <?php $__currentLoopData = $city_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option><?php echo e($city->Ten); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  <?php else: ?>
                    <?php $__currentLoopData = $city_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($city->Ten); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>     
                </optgroup>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
                  <select name="salary[]" class="selectpicker" data-style="btn-white btn-lg" data-width="100%" data-live-search="true" title="Chọn mức lương..." data-size="10" data-max-options="3" multiple>  
                  <?php if(isset($search_info)): ?>
                    <?php if(isset($search_info['salary'])): ?>          
                      <?php $__currentLoopData = $salary_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option <?php echo e(in_array($salary,$search_info['salary']) ? 'selected' : ''); ?>>
                        <?php echo e($salary); ?>

                      </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                      <?php $__currentLoopData = $salary_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option><?php echo e($salary); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  <?php else: ?>
                    <?php $__currentLoopData = $salary_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($salary); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </select>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
                  <button type="submit" class="btn btn-info btn-lg btn-block text-white btn-search"><span class="icon-find_in_page mr-1"></span>Tìm kiếm hồ sơ</button>
                </div>
              </div>

              <!-- NÂNG CAO --> 
    <div class="row mb-5">
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
      <a class="text-white" id="advanced-search" href="javascript:void(0)" style="text-decoration: none;">
      Tìm kiếm nâng cao 
      <?php if(isset($search_info)): ?>
        
        <?php if(isset($search_info['sex']) || isset($search_info['number']) || isset($search_info['status']) || 
         isset($search_info['job']) || isset($search_info['skill']) || isset($search_info['rank']) || isset($search_info['degree']) || isset($search_info['exp'])): ?>
        <span class="icon-chevron-down"></span>
        <?php else: ?>
        <span class="icon-chevron-right"></span>  
        <?php endif; ?>      
      <?php else: ?>
      <span class="icon-chevron-right"></span>
      <?php endif; ?>
      </a>  
      </div>
    </div>  
      
    <!-- HÀNG 1 -->
    <div class="row mb-5 advanced-search-form">
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">    
      <select name="job[]" class="selectpicker" data-style="btn-white btn-lg" data-width="100%" data-live-search="true" title="Chọn thêm ngành nghề..." data-size="10" data-max-options="3" multiple>       
        <?php if(isset($search_info)): ?>
          <?php if(isset($search_info['job'])): ?>         
            <?php $__currentLoopData = $job_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e(in_array($job,$search_info['job']) ? 'selected' : ''); ?>>
              <?php echo e($job); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <?php $__currentLoopData = $job_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option><?php echo e($job); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        <?php else: ?>
          <?php $__currentLoopData = $job_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option><?php echo e($job); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </select>
      </div>

      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
      <select name="skill[]" class="selectpicker" data-style="btn-white btn-lg" data-width="100%" data-live-search="true" title="Chọn kĩ năng..." data-size="10" data-max-options="5" multiple>       
          <?php if(isset($search_info)): ?>
          <?php if(isset($search_info['skill'])): ?>         
            <?php $__currentLoopData = $skill_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e(in_array($skill,$search_info['skill']) ? 'selected' : ''); ?>>
              <?php echo e($skill); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <?php $__currentLoopData = $skill_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
              <option><?php echo e($skill); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        <?php else: ?>
          <?php $__currentLoopData = $skill_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <option><?php echo e($skill); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </select>
      </div>
    
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
      <select name="degree[]" class="selectpicker" data-style="btn-white btn-lg" data-width="100%" data-live-search="true" title="Chọn bằng cấp..." data-size="10" data-max-options="3" multiple>       
        <?php if(isset($search_info)): ?>
          <?php if(isset($search_info['degree'])): ?>          
            <?php $__currentLoopData = $degree_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e(in_array($degree,$search_info['degree']) ? 'selected' : ''); ?>>
              <?php echo e($degree); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <?php $__currentLoopData = $degree_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option><?php echo e($degree); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        <?php else: ?>
          <?php $__currentLoopData = $degree_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option><?php echo e($degree); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </select>
      </div>

      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
      <select name="rank[]" class="selectpicker" data-style="btn-white btn-lg" data-width="100%" data-live-search="true" title="Chọn cấp bậc..." data-size="10" data-max-options="3" multiple>
        <?php if(isset($search_info)): ?>
          <?php if(isset($search_info['rank'])): ?>          
            <?php $__currentLoopData = $rank_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e(in_array($rank,$search_info['rank']) ? 'selected' : ''); ?>>
              <?php echo e($rank); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <?php $__currentLoopData = $rank_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option><?php echo e($rank); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        <?php else: ?>
          <?php $__currentLoopData = $rank_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option><?php echo e($rank); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </select>
      </div>
    </div>
    <!-- END HÀNG 1 -->
    <!-- HÀNG 2 -->
    <div class="row mb-5 advanced-search-form">
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">  
      <select name="sex" class="selectpicker" data-style="btn-white btn-lg" data-width="100%" data-live-search="true" title="Chọn giới tính...">
        <option value="">Bất kì giới tính nào</option>
        <option <?php if(isset($search_info['sex'])): ?> <?php echo e($search_info['sex'] == 'Nam' ? 'selected' : ''); ?><?php endif; ?>>Nam</option>
        <option <?php if(isset($search_info['sex'])): ?> <?php echo e($search_info['sex'] == 'Nữ' ? 'selected' : ''); ?><?php endif; ?>>Nữ</option>        
      </select>
      </div>

      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
      <select name="exp" class="selectpicker" data-style="btn-white btn-lg" data-width="100%" data-live-search="true" title="Chọn kinh nghiệm...">
        <option value="">Bất kì kinh nghiệm nào</option>
          <?php if(isset($search_info)): ?>
          <?php if(isset($search_info['exp'])): ?>                     
            <?php $__currentLoopData = $exp_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
              <option <?php echo e($exp == $search_info['exp'] ? 'selected' : ''); ?>>
              <?php echo e($exp); ?>

              </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <?php $__currentLoopData = $exp_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
              <option><?php echo e($exp); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        <?php else: ?>
          <?php $__currentLoopData = $exp_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <option><?php echo e($exp); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </select>
      </div>

      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
      <select name="status" class="selectpicker" data-style="btn-white btn-lg" data-width="100%" data-live-search="true" title="Chọn hình thức..."> 
        <option value="">Bất kì hình thức nào</option>
        <option <?php if(isset($search_info['status'])): ?> <?php echo e($search_info['status'] == 'Full Time' ? 'selected' : ''); ?><?php endif; ?>>Full Time</option>
        <option <?php if(isset($search_info['status'])): ?> <?php echo e($search_info['status'] == 'Part Time' ? 'selected' : ''); ?><?php endif; ?>>Part Time</option>
      </select>
      </div> 

      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
        <input type="reset" id="reset-form" class="form-control btn-danger" value="Reset Form">
      </div>   
    </div>
    <!-- END HÀNG 2 -->   
    <!-- HÀNG 3 -->
    <!-- <div class="row form-group mb-5 advanced-search-form">
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
        <input type="reset" id="reset-form" class="form-control btn-danger" value="Reset Form">
      </div>

      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
        <div class="form-check">
          <input class="form-check-input" type="radio" name="condition" value="or" checked>
          <label class="form-check-label text-white" for="Or">          
          Thoả 1 trong số điều kiện trên
          </label>
        </div>
      </div>

      <div class="col-12 col-sm-6 col-md-6 col-lg-5 mb-4 mb-lg-0">        
        <div class="form-check">          
          <input class="form-check-input" type="radio" name="condition" value="or">
          <label class="form-check-label text-white" for="And">
          Thoả tất cả những điều kiện trên
          </label>
        </div>
      </div>
    </div> -->
    <!-- END HÀNG 3 -->   
    </form>
    <!-- END NÂNG CAO  -->

              <div class="row">
                <div class="col-md-12 popular-keywords">
                  <h3>Trending Keywords:</h3>
                  <ul class="keywords list-unstyled m-0 p-0">
                    <li><a href="#" class="">UI Designer</a></li>
                    <li><a href="#" class="">Python</a></li>
                    <li><a href="#" class="">Developer</a></li>
                  </ul>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>

      <a href="#next" class="scroll-button smoothscroll">
        <span class=" icon-keyboard_arrow_down"></span>
      </a>
    </section>
<script src="<?php echo e(url('ajax/autocomplete.js')); ?>"></script>
<script>
  $(document).ready(function(){   
    <?php if(isset($search_info)): ?>
    <?php if(isset($search_info['sex']) || isset($search_info['number']) || isset($search_info['status']) || isset($search_info['job']) || isset($search_info['skill']) || isset($search_info['rank']) || isset($search_info['degree']) || isset($search_info['exp'])): ?>
    $(".advanced-search-form").css({'display':'flex'});
    <?php else: ?> $(".advanced-search-form").css({'display':'none'});
    <?php endif; ?>
    <?php else: ?>
    $(".advanced-search-form").css({'display':'none'});
    <?php endif; ?>
  });

  $("#reset-form").click(function(){
    $(".selectpicker").val('default');
    $(".selectpicker").selectpicker("refresh");
    $('.selectpicker option[value=All]').click(function(){
        $('.selectpicker option').each(function(){
            this.selected = $('.selectpicker option[value=All]').attr('selected');
        });
    });
  });
  
  $("#advanced-search").click(function(){   
    $(".advanced-search-form").slideToggle("slow");
    $(this).children(":last-child").toggleClass(['icon-chevron-down','icon-chevron-right']);    
  });
</script>