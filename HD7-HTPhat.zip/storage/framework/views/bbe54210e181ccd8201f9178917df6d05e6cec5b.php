<?php $__env->startSection('content'); ?>
<div class="content-page">
<!-- Start content -->
    <div class="content">

        <div class="">
            <div class="page-header-title">
                <h4 class="page-title">Tin tuyển dụng</h4>
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <?php echo e(session('success')); ?> <a href="#" class="alert-link">Alert Link</a>.
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <?php echo e(session('error')); ?> <a href="#" class="alert-link">Alert Link</a>.
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="page-content-wrapper">                    
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">                     
                        <div class="card">
                            <?php if(!empty($job_list)): ?>
                            <div class="card-body">
                                <h4 class="m-b-30 m-t-0">
                                    Danh sách tin tuyển dụng (Tổng cộng có <?php echo e($job_list->count()); ?> tin) 
                                    <a href="<?php echo e(url('/administrators/tin-tuyen-dung/clear')); ?>"><button class="btn btn-danger float-right">Xoá tin đã hết hạn</button></a>
                                </h4>
                                <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>ngành tuyển dụng</th>
                                        <th>Mức lương</th>                                      
                                        <th>Trạng thái xử lý</th>
                                        <th>Khu vực</th>
                                        <th>Ngày đăng</th>
                                        <th>Thao tác</th>
                                        <th>Hạn tuyển dụng</th>
                                        <th>Mô tả công việc</th>
                                        <th>Quyền lợi</th>
                                        <th>Thông tin liên hệ</th>
                                        <th>Yêu cầu công việc</th>
                                        <th>Yêu cầu ngoại ngữ</th>
                                        <th>Yêu cầu tin học</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $job_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($job->id); ?></td>
                                        <td><?php echo e($job->nganh); ?></td>
                                        <td><?php echo e($job->mucluong); ?></td>
                                        <td>
                                            <?php if($job->ad_pheduyet == 0): ?>
                                            <span class="badge badge-danger">Chưa xử lý</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php $__currentLoopData = json_decode($job->tinhthanhpho); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge badge-warning"><?php echo e($city); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td><?php echo e(date('d/m/Y',strtotime($job->updated_at))); ?></td>
                                        <td>
                                            <div class="dropdown">
                                              <button class="btn btn-light dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Quản lý
                                              </button>
                                              <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <a class="dropdown-item" href="<?php echo e(url('/administrators/tin-tuyen-dung/phe-duyet/'.$job->id)); ?>">Duyệt</a>
                                                <a class="dropdown-item" href="<?php echo e(url('/administrators/tin-tuyen-dung/view-pdf',$job->id)); ?>" target="_blank">Xem PDF</a>
                                                <a class="dropdown-item" href="<?php echo e(url('/administrators/tin-tuyen-dung/export-pdf',$job->id)); ?>" target="_blank">Xuất PDF</a>
                                              </div>
                                            </div>
                                        </td>
                                        <td><?php echo e(date('d/m/Y',strtotime($job->hantuyendung))); ?></td>
                                        <td>                                                                <ul class="list-group">
                                            <?php if($job->motacv): ?>
                                            <?php $__currentLoopData = json_decode($job->motacv); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $des): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item"><span class="badge badge-primary"><?php echo e($des); ?></span></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            </ul>
                                        </td>
                                        <td>
                                            <ul class="list-group">
                                            <?php if($job->quyenloi): ?>
                                            <?php $__currentLoopData = json_decode($job->quyenloi); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benefit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item"><span class="badge badge-secondary"><?php echo e($benefit); ?></span></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            </ul>
                                        </td>
                                        <td>
                                            <?php echo e($job->ttlienhe); ?>

                                        </td>   
                                        <td><?php echo e($job->yeucau_cv); ?></td>
                                        <td>
                                            <?php echo e($job->ngoaingu); ?>

                                        </td>
                                        <td>
                                            <?php echo e($job->tinhoc); ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php else: ?> <h4>Không có tin nào cả!</h4>
                            <?php endif; ?>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>