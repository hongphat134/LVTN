<?php if($job_listings->lastPage() != 1 && $job_listings->currentPage() <= $job_listings->lastPage()): ?>
<div class="row pagination-wrap">
          <div class="col-md-6 text-center text-md-left mb-4 mb-md-0">
            <span>
Hiển thị 1-<?php echo e($job_listings->perPage()); ?> trong <strong><?php echo e($job_listings->total()); ?>

<?php if(!isset($job_listings->typeRecord)): ?> <span class="alert alert-danger"> No Type Record</span>
<?php else: ?>
	<?php if($job_listings->typeRecord == 0): ?>
		hồ sơ
	<?php elseif($job_listings->typeRecord == 1): ?>
		tin tuyển dụng
	<?php elseif($job_listings->typeRecord == 2): ?>
		nhà tuyển dụng
	<?php else: ?>
		bài viết
	<?php endif; ?>
<?php endif; ?>
</strong>
            </span>
          </div>
<div class="col-md-6 text-center text-md-right">
	<div class="custom-pagination ml-auto">
		<?php if($job_listings->currentPage() != 1): ?>		
		<a href="<?php echo e($job_listings->url($job_listings->currentPage() - 1)); ?>" class="prev">Trước</a>
		<?php endif; ?>
		<div class="d-inline-block">
		<?php for($i = 1; $i <=  $job_listings->lastPage(); $i++): ?>
		
		<?php if($job_listings->currentPage() == $i): ?>
		<a class="active" href="javascript:void(0)"><?php echo $i; ?></a>

		<?php elseif(($i == $job_listings->currentPage() - 1 || $i == $job_listings->currentPage() - 2 || $i == $job_listings->currentPage() + 1 || $i == $job_listings->currentPage() + 2) || $i == $job_listings->lastPage() || $i == 1): ?>
		<a href="<?php echo e($job_listings->url($i)); ?>"><?php echo $i; ?></a>
		
		<?php elseif(($i == $job_listings->lastPage() - 1 || $i == 2) && $job_listings->lastPage() > 5): ?>
            <sub><i class="icon-ellipsis-h"></i></sub>
				
		<?php endif; ?>
		<?php endfor; ?>
		</div>		
		<?php if($job_listings->currentPage() != $job_listings->lastPage()): ?>        
        <a href="<?php echo e($job_listings->url($job_listings->currentPage() + 1)); ?>" class="next">Sau</a>                 
        <?php endif; ?>
	</div>
</div>
</div>
<?php endif; ?>

