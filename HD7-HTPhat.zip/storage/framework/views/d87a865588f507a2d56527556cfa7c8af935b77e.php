<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
<!-- Required datatable js-->
<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
    $(document).ready(function(){
        $("#datatable-responsive").DataTable({              
        });
    });
</script>  
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Danh sách hồ sơ ứng tuyển</h1>
            <div class="custom-breadcrumbs">
              <a href="#">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Hồ sơ xin việc</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>
    
<section class="site-section services-section bg-light block__62849" id="next-section">
  <div class="container">
    <div class="row">
      <div class="col-lg-8">
      <h3 class="text-center"><span class="icon-done_all mr-2"></span>Danh sách hồ sơ đã xử lý <span class="icon-done_all"></span></h3>
      <?php if(session('success')): ?>
       <div class="alert alert-success alert-dismissible fade show">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong>Hoàn tất!</strong> <?php echo e(session('success')); ?>

      </div>
      <?php endif; ?>     
      <form action="#">
        Từ ngày: <input type="date" name="key" value="">
        - Đến ngày: <input type="date" name="key" value="">
        <button class="btn btn-info"><span class="icon-search"></span></button>
      </form>
      <?php if($profile_list->count() != 0): ?>
      <form action="<?php echo e(url('/nhatuyendung/xoa-ho-so')); ?>">
      <table id="datatable-responsive" class="table table-bordered table-hover">
        <thead style="font-weight: bold">
        <tr>
          <td>STT</td>
          <td>Nội dung đã gửi</td>
          <td>Giờ xử lý</td>
          <td>Thao tác</td>
          <td>
            <button id="checkAll" type="button" class="btn btn-primary">Chọn tất</button>
          </td>
        </tr>
        </thead>          
        <tbody>
        <?php $__currentLoopData = $profile_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td>Hồ sơ <?php echo e($profile->id); ?></td>
          <td><?php echo e(limit_description($profile->noidung_ungtuyen)); ?></td>
          <td><?php echo e(date('H \g\i\ờ d/m/Y',strtotime($profile->updated_at))); ?></td>
          <td>
            <!-- Example split danger button -->
  <div class="btn-group">
  <button type="button" class="btn btn-info" data-toggle="modal" data-target="#Profile<?php echo e($key); ?>Modal">Xem</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
  <a class="dropdown-item" target="_blank" href="<?php echo e(url('nhatuyendung/ung-tuyen/pdf',[$profile->idUser,$profile->idTTD])); ?>">Xuất PDF</a>
  <a class="dropdown-item" href="#">Another action</a>
  <a class="dropdown-item" href="#">Something else here</a>
  <div class="dropdown-divider"></div>
  <a class="dropdown-item" href="#">Separated link</a>
  </div>
  </div>             
          </td>
          <td>
            <input type="checkbox" name="recCheckbox[]" value="<?php echo e($profile->idUser); ?> <?php echo e($profile->idTTD); ?>">
          </td>
        </tr>          
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

        <tfoot style="font-weight: bold">
        <tr>
          <td>STT</td>
          <td>Nội dung đã gửi</td>
          <td>Giờ xử lý</td>
          <td>Thao tác</td>
          <td>
            <button id="uncheckAll" type="button" class="btn btn-danger">Xoá tất</button>
          </td>
        </tr>
        </tfoot>
      </table>
                   
      <button type="submit" id="recBtn" class="btn btn-danger">Xoá những hồ sơ đã chọn</button>
      <?php else: ?>
      Hiện tại chưa có hồ sơ nào cả! Hãy kiên nhẫn chờ đợi bạn nhé!
      <?php endif; ?> 
      </div>  

      <div class="col-lg-4 border p-5">
        <h4>Thông tin tuyển dụng</h4>
        <p>Ngành cần tuyển: <?php echo e($job->nganh); ?></p>
        <p>Số lượng: <?php echo e($job->soluong); ?></p>
        <p>Mức lương: <?php echo e($job->mucluong); ?></p>
        <p>Vị trí: <?php echo e($job->capbac); ?></p>
        <p>Hình thức làm việc: <?php echo e($job->hinhthuc_lv); ?></p>
        <p class="text-danger">Hạn tuyển dụng: <?php echo e(date('d/m/Y',strtotime($job->hantuyendung))); ?></p>
        <p>Khu vực: 
          <?php $__currentLoopData = json_decode($job->tinhthanhpho); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($city); ?> #
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </p>

        <h4>Yêu cầu</h4>
        <p>Bằng cấp: <?php echo e($job->bangcap); ?></p>
        <p>Giới tính: <?php echo e($job->gioitinh); ?></p>
        <p>Kinh nghiệm: <?php echo e($job->kinhnghiem); ?></p>
        <p>Kĩ năng: 
        <?php $__currentLoopData = json_decode($job->kinang); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($skill); ?> #
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>

        <h4>Yêu cầu khác</h4>
        <?php if($job->ngoaingu): ?>
        <p>Ngoại ngữ: 
          <?php $__currentLoopData = json_decode($job->ngoaingu); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($language); ?> &
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </p>
        <?php endif; ?>
        <?php if($job->tinhoc): ?>
        <p>Tin học: 
          <?php $__currentLoopData = json_decode($job->tinhoc); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($itech); ?> &
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>        
        <?php endif; ?>

        <?php if($job->yeucau_cv): ?>
        <h4>Yêu cầu thêm</h4>
        <?php echo nl2br($job->yeucau_cv); ?>

        <?php endif; ?>
      </div> 
    </div>
  </div>
</section>
</form>

<script>
  $("#checkAll").click(function(){
      const checkboxList = $("input[type='checkbox']");               
      checkboxList.prop('checked',true);            
  });
  $("#uncheckAll").click(function(){
      const checkboxList = $("input[type='checkbox']");               
      checkboxList.prop('checked',false);            
  });
  $("#recBtn").click(function(e){
    if($("input[type='checkbox']").is(":checked") == false){            
      $(this).attr('data-target','');
      alert("Bạn chưa chọn hồ sơ nào cả!");      
    }
    else  $(this).attr('data-target','#recModal');   
  });
</script>
<?php $__currentLoopData = $profile_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Profile Modal -->
  <div class="modal fade" id="Profile<?php echo e($key); ?>Modal" style="z-index: 9999">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Thông tin hồ sơ ứng tuyển</span></h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
<section class="site-section" style="padding-top: 0">
<div class="container">
<div class="row">
<div class="col-lg-8 blog-content">
<h3 class="mb-4"><?php echo e($profile->nganh); ?></h3>
<p class="lead">Trình độ <?php echo e($profile->bangcap); ?></p>        

<blockquote><p>Vị trí đã từng đảm nhiệm <?php echo e($profile->capbac); ?></p></blockquote>
  
<p>Khu vực sinh sống <?php echo e($profile->khuvuc); ?></p>

<p><span class="text-danger">Ngày sinh: <?php echo e(date('d/y/Y',strtotime($profile->ngaysinh))); ?></span> - <span class="text-primary">Giới tính: <?php echo e($profile->gioitinh); ?></span></p>

<h4 class="mt-5 mb-4">Hình thức làm việc mong muốn: <?php echo e($profile->hinhthuc_lv); ?></h4>

<p>Tình trạng hôn nhân: <?php echo e($profile->honnhan); ?></p>
<p>Kinh nghiệm làm việc: <?php echo e($profile->kinhnghiem); ?></p>
<p class="text-info">Mức lương mong muốn: <?php echo e($profile->mucluongmm); ?></p>

<h4 class="mt-5 mb-4">Thông tin liên hệ:</h4>
<p>Email liên hệ: <?php echo e($profile->emaillienhe); ?></p>
<p>SDT liên hệ: <?php echo e($profile->sdtlienhe); ?></p>

<div class="pt-5">
<p><h4>Mục tiêu:</h4>
  <?php echo nl2br($profile->muctieu); ?></p>
</div>

<div class="pt-5">
<p><h4>Thông tin thêm:</h4>
  <?php echo nl2br($profile->thongtinthem); ?></p>
</div>

<div class="pt-5 text-danger">
  <p><h4>Nội dung đã gửi cho ứng viên:</h4>
  <strong><?php echo nl2br($profile->noidung_ungtuyen); ?></strong>
  </p>
</div>

</div>
<div class="col-lg-4 sidebar pl-lg-5">
<div class="sidebar-box">
<?php if($profile->hinh): ?>
<img src="<?php echo e(asset('hinhdaidien/'.$profile->hinh)); ?>" alt="<?php echo e($profile->hinh); ?>" class="img-fluid mb-4 w-50 rounded-circle">
<?php else: ?>
<img src="<?php echo e(asset('hinhdaidien/default.png')); ?>" alt="Default" class="img-fluid mb-4 w-50 rounded-circle">
<?php endif; ?>
<h3><?php echo e($profile->hoten); ?></h3>
<p><strong>Sở trường:</strong></br> <i><?php echo nl2br($profile->sotruong); ?></i></p>
<p><a href="#" class="btn btn-primary btn-sm">Mô tả sơ lược</a></p>
</div>

<div class="sidebar-box">
  <div class="categories">
  <h3>Kỹ năng</h3>
    <div>
    <?php $__currentLoopData = json_decode($profile->kinang); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="#"><?php echo e($skill); ?> <span class="icon-star"></span></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>

<div class="sidebar-box">
<div class="categories">
<h3>Trình độ ngoại ngữ</h3>
<div>
<?php if($profile->ngoaingu): ?>
<?php $__currentLoopData = json_decode($profile->ngoaingu); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><a href="#"><?php echo e($language); ?> <span class="icon-star"></span></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</div>
</div>
</div>

<div class="sidebar-box">
<div class="categories">
<h3>Trình độ tin học</h3>
<div>
<?php if($profile->tinhoc): ?>
<?php $__currentLoopData = json_decode($profile->tinhoc); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><a href="#"><?php echo e($itech); ?> <span class="icon-star"></span></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</div>
</div>
</div>

</div>
</div>
</div>
</section>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
        </div>
        
      </div>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>