<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Danh sách hồ sơ đã lưu</h1>
            <div class="custom-breadcrumbs">
              <a href="#">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Hồ sơ đã lưu</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section services-section bg-light block__62849" id="next-section">
      <div class="container">
        <?php if($profile_list->total() != 0): ?>
        <h2 class="section-title mb-2">Bạn đang theo dõi <?php echo e($profile_list->total()); ?> mẫu hồ sơ </h2>
        <div class="row">
          <?php $__currentLoopData = $profile_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-6 col-md-6 col-lg-4 mb-4 mb-lg-5">

            <a href="<?php echo e(route('detailPf',$profile->id)); ?>" class="block__16443 text-center d-block">
              <span class="custom-icon mx-auto"><span class="icon-file-text d-block"></span></span>
              <h3><?php echo e($profile->hoten); ?></h3>
              <p><?php echo e($profile->nganh); ?></p>
              <p><?php echo e($profile->khuvuc); ?></p>
              <p><?php echo e(date('d/m/Y',strtotime($profile->created_at))); ?></p>
            </a>

          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
        </div>    
        
        <!-- Phân trang chưa truyền biến dc :( -->
          <?php echo $__env->make('layouts.paginating',['job_listings' => $profile_list], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
        <?php else: ?>
          <h4 class="section-title mb-2">Bạn chưa theo dõi <a href="<?php echo e(url('/nhatuyendung/danh-sach-ho-so')); ?>">hồ sơ</a> nào cả! Hãy xem <a href="<?php echo e(url('/nhatuyendung/danh-sach-ho-so')); ?>">hồ sơ</a> công khai  của người tìm việc để tìm kiếm nhân lực phù hợp và nhanh chóng bạn nhé!</h4>
        <?php endif; ?>  
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>