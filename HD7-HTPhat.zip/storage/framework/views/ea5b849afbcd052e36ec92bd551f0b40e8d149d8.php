<?php $__env->startSection('content'); ?>


<div class="content-page">
<!-- Start content -->
    <div class="content">

        <div class="">
            <div class="page-header-title">
                <h4 class="page-title">Phê duyệt mẫu hồ sơ</h4>
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <?php echo e(session('success')); ?> <a href="#" class="alert-link">Alert Link</a>.
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <?php echo e(session('error')); ?> <a href="#" class="alert-link">Alert Link</a>.
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="page-content-wrapper">                    
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">                     
                        <div class="card">
                            <?php if(!empty($profile_list)): ?>
                            <div class="card-body">
                                <h4 class="m-b-30 m-t-0">
                                    Danh sách mẫu hồ sơ (Tổng cộng có <?php echo e($profile_list->count()); ?> hồ sơ)                                 
                                </h4>
                                <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Họ tên</th>
                                        <th>Email liên hệ</th>                                      
                                        <th>SDT liên hệ</th>
                                        <th>Ngành nghề</th>                                     
                                        <th>Ngày đăng</th>
                                        <th>Trạng thái xử lý</th>
                                        <th>Thao tác</th>
                                        <th>Mục tiêu</th>                                  
                                        <th>Sở trường</th>
                                        <th>Thông tin thêm</th>
                                        <th>Ngoại ngữ</th>
                                        <th>Tin học</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $profile_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($profile->id); ?></td>
                                        <td><?php echo e($profile->hoten); ?></td>
                                        <td><?php echo e($profile->emaillienhe); ?></td>
                                        <td><?php echo e($profile->sdtlienhe); ?></td>
                                        <td><?php echo e($profile->nganh); ?></td>
                                        <td><?php echo e(date('d/m/Y',strtotime($profile->updated_at))); ?></td>
                                        <td>
                                            <?php if($profile->ad_pheduyet == 0): ?>
                                            <span class="badge badge-danger">Chưa xử lý</span>      
                                            <?php endif; ?>
                                        </td>
                                        <td><a href="<?php echo e(url('/administrators/ho-so/phe-duyet',$profile->id)); ?>"><button class="btn btn-white">Phê duyệt</button></a></td>
                                        <td><?php echo nl2br($profile->muctieu); ?></td>
                                        <td><?php echo nl2br($profile->sotruong); ?></td>
                                        <td><?php echo nl2br($profile->thongtinthem); ?></td>
                                        <td>
                                            <?php if($profile->ngoaingu): ?>
                                            <?php $__currentLoopData = json_decode($profile->ngoaingu); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($lang); ?> #
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                         
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($profile->tinhoc): ?>
                                            <?php $__currentLoopData = json_decode($profile->tinhoc); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($itech); ?> #
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                         
                                            <?php endif; ?>
                                        </td>
                                    </tr>                                       
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php else: ?> <h4>Không có mẫu hồ sơ nào cả!</h4>
                            <?php endif; ?>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>