<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- MENU -->
    <?php echo $__env->make('ntv_layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- HOME -->
    <?php echo $__env->make('layouts.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
<section class="site-section" id="next">
<div class="container">
	<div class="row mb-5">
		<div class="col-12 col-md-8 col-sm-12 col-lg-7">
			<form action="<?php echo e(url('nguoitimviec/tim-kiem-ntd')); ?>" method="post">
			<?php echo e(csrf_field()); ?>

			<div style="margin-left: -14px">
			<div class="col-10 col-xs-9 col-sm-9 col-md-10 col-lg-10 d-inline-flex">
				<input type="text" name="key" class="form-control" placeholder="Tên nhà tuyển dụng...." value="<?php echo e(isset($key)?$key:''); ?>" autofocus>	
			</div>
			
			<button type="submit" class="btn btn-info" style="margin-left: -14px"><span class="icon-search"></span></button>
			</form>
			
			</div>
		<div class="clear-fix" style="margin-bottom: 10px"></div>
		<?php if(count($ntd_list) > 0): ?>
		<?php $__currentLoopData = $ntd_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ntd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>		
			<div class="card d-inline-flex" style="width:200px">
		    <a href="<?php echo e(url('/thong-tin-ntd',$ntd->idUser)); ?>"><img class="card-img-top" src="<?php echo e(asset('/logo/'.$ntd->hinh)); ?>" alt="Card image" style="width:100%; height: 150px"></a>
		    <div class="card-body">
		      <h4 class="card-title"><a href="<?php echo e(url('/thong-tin-ntd',$ntd->idUser)); ?>"><?php echo e($ntd->ten); ?></a></h4>
		      <p class="card-text"><?php echo e($ntd->tinhthanhpho); ?></p>
		      <?php if(Auth::user()->theodoi_ntd): ?>
		      	<?php if(in_array($ntd->idUser,json_decode(Auth::user()->theodoi_ntd))): ?>
		      	<a href="javascript:void(0)" id="<?php echo e($ntd->idUser); ?>" class="btn btn-danger theo-doi">ĐANG THEO DÕI</a>	
		      	<?php else: ?>
		      	<a href="javascript:void(0)" id="<?php echo e($ntd->idUser); ?>" class="btn btn-outline-danger theo-doi follow-rec">THEO DÕI</a>
		      	<?php endif; ?>
		      <?php else: ?>
		      <a href="javascript:void(0)" id="<?php echo e($ntd->idUser); ?>" class="btn btn-outline-danger theo-doi follow-rec">THEO DÕI</a>
		      <?php endif; ?>
		    </div>
		  </div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php echo $__env->make('layouts.paginating',['job_listings' => $ntd_list], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php else: ?>
		Không tìm thấy nhà tuyển dụng nào cả!
		<?php endif; ?>
		</div>
		<div class="col-12 col-md-4 col-sm-12 col-lg-5">
			<?php if(Auth::user()->theodoi_ntd): ?>
			<h4>Đang theo dõi <count><?php echo e(count(json_decode(Auth::user()->theodoi_ntd))); ?></count> nhà tuyển dụng</h4>
			<table class="table table-bordered">
				<thead style="font-weight: bold">
				<tr>
					<td>Tên nhà tuyển dụng</td>
					<td>Số lượng tin mới</td>
				</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $f_ntd_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ntd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td>
						<a href="<?php echo e(url('/thong-tin-ntd',$ntd->idUser)); ?>"><?php echo e($ntd->ten); ?></a> 
						<a id="<?php echo e($ntd->idUser); ?>" class="unfollow-ntd theo-doi" href="javascript:void(0)"><span class="badge badge-secondary"><span class="icon-close mr-1"></span>Huỷ theo dõi</span></a>
					</td>
					<td>Có <?php echo e($ntd->count); ?> tin mới</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			<?php else: ?>
			<h5>Bạn chưa theo dõi nhà tuyển dụng nào cả! Hãy theo dõi để nhận được thông báo từ nhà tuyển dụng đấy nhé!</h5>
			<?php endif; ?>
		</div>
	</div>
</div>
</section>
<script>
	$(".unfollow-ntd").click(function(){
		$(this).parent().parent().remove();
		$('count').text($('count').text() - 1);
	});
</script>
<script src="<?php echo e(url('ajax/follow-recruiters.js')); ?>"></script>
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    