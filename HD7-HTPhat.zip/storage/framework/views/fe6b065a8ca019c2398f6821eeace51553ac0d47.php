<?php $__env->startSection('content'); ?>
    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url(<?php echo e(url('images/hero_1.jpg')); ?>)" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Danh sách Blog</h1>
            <div class="custom-breadcrumbs">
              <a href="<?php echo e(url('/')); ?>">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Quản lý Blog</strong> /</span>
              
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section">
      <div class="container">
        <div class="row">
        	<div class="col-lg-8">
        	<table class="table table-striped">
        		<thead>
        			<tr style="font-weight: bold;">
        				<td>Tiêu đề</td>        				
        				<td>Hình</td>
        				<td>Ngày tạo</td>
        				<td>Trạng thái</td>
        				<td>Thao tác</td>        				
        			</tr>
        		</thead>

        		<tbody>
        			<?php $__currentLoopData = $blog_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        			<tr>
        				<td><?php echo e($blog->tieude); ?></td>        				
        				<td>
        					<img src="<?php echo e(asset('/blog_images/'.$blog->hinh)); ?>" alt="" style="width: 150px; height: 100px">
        					
        				</td>
        				<td><?php echo e(date('d-m-Y',strtotime($blog->created_at))); ?></td>
        				<td>
        					<?php if($blog->trangthai == 0): ?>
        					<span class="badge badge-danger">Chờ duyệt</span>
        					<?php else: ?>
        					<span class="badge badge-success">Đã duyệt</span>
        					<?php endif; ?>
        				</td>
        				<td><a href="<?php echo e(url('/update-blog',$blog->id)); ?>">Cập nhật</a></td>
        			</tr>
        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		</tbody>

        	</table>
             <?php echo $__env->make('layouts.paginating',['job_listings' => $blog_list], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>